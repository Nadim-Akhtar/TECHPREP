# TechPrep — Prepare Smart. Get Hired.

A full stack placement preparation platform for CSE students: DSA, full stack development,
aptitude, reasoning, core computer science, system design, interview prep and company guides —
with per-user progress, notes and a revision list.

Stack: **React (Vite) + Tailwind CSS** on the frontend, **Node + Express + MongoDB (Mongoose)** on the backend, JWT auth.

---

## 1. Requirements

- Node.js 18 or newer
- MongoDB running locally, **or** a free MongoDB Atlas connection string

## 2. Setup

```bash
# from the project root
npm run install:all          # installs backend + frontend dependencies
```

Or install them separately:

```bash
cd backend && npm install
cd ../frontend && npm install
```

## 3. Environment variables

`backend/.env` (a working default is already included, change the secret before deploying):

```
PORT=5000
NODE_ENV=development
MONGO_URI=mongodb://127.0.0.1:27017/techprep
JWT_SECRET=change_this_to_a_long_random_string
JWT_EXPIRES_IN=30d
CLIENT_URL=http://localhost:5173
```

For MongoDB Atlas, replace `MONGO_URI` with your cluster string.

`frontend/.env`:

```
VITE_API_URL=http://localhost:5000/api
```

## 4. Seed the content

This loads 180+ topics and problems, 44 quiz questions, 15 interview answers and 8 company guides.

```bash
cd backend
npm run seed
```

Demo login created by the seed: **nadim@techprep.dev / test1234**

To wipe everything including users: `npm run seed:destroy`

## 5. Run it

Two terminals:

```bash
# terminal 1
cd backend && npm run dev      # http://localhost:5000

# terminal 2
cd frontend && npm run dev     # http://localhost:5173
```

Open http://localhost:5173

---

## Project structure

```
techprep/
├── backend/
│   └── src/
│       ├── config/db.js            MongoDB connection
│       ├── models/                 User, Problem, Progress, Question, Attempt,
│       │                           InterviewQuestion, Company, Track
│       ├── controllers/            auth, problem, progress, quiz, content
│       ├── routes/                 /api/auth /api/problems /api/progress
│       │                           /api/questions /api/content
│       ├── middleware/             JWT protect, optionalAuth, error handling
│       ├── seed/                   seed script + all content data
│       └── server.js
└── frontend/
    └── src/
        ├── api/client.js           axios instance with token interceptor
        ├── context/                AuthContext, ThemeContext (light/dark)
        ├── components/             Navbar, DashboardLayout, ProgressRing, StatCard...
        └── pages/                  Home, Login, Register, Dashboard, TrackSheet,
                                    Quiz, Interview, Companies, Profile
```

## API reference

| Method | Endpoint | Auth | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | — | Create account, returns JWT |
| POST | `/api/auth/login` | — | Sign in, returns JWT |
| GET | `/api/auth/me` | yes | Current user |
| PUT | `/api/auth/me` | yes | Update profile and daily goal |
| GET | `/api/problems?track=dsa` | optional | Flat problem list with your progress |
| GET | `/api/problems/roadmap?track=dsa` | optional | Section → topic → problem tree with counts |
| GET | `/api/problems/random?track=dsa` | — | One random problem |
| GET | `/api/progress/summary` | yes | Dashboard stats and per-track percentages |
| PATCH | `/api/progress/:problemId/solve` | yes | Toggle solved, updates streak |
| PATCH | `/api/progress/:problemId/revision` | yes | Star for revision |
| PUT | `/api/progress/:problemId/note` | yes | Save a personal note |
| GET | `/api/questions?track=aptitude&limit=10` | — | Random quiz set (answers hidden) |
| GET | `/api/questions/topics?track=aptitude` | — | Topic list with counts |
| POST | `/api/questions/submit` | yes | Score a quiz, returns explanations |
| GET | `/api/content/interview` | — | Interview question bank |
| GET | `/api/content/companies` | — | Company hiring guides |

## Features

- Email and password auth with hashed passwords and JWT
- Per-user progress on every topic, with solved counts by difficulty
- Personal notes and a revision list per problem
- Daily streak that updates whenever you solve or take a quiz
- Timed aptitude, reasoning and core CS quizzes with explanations after scoring
- Interview answer bank grouped by HR, behavioural, technical and system design
- Company guides with round structure, focus areas and frequently asked problems
- Light and dark theme, responsive down to mobile, keyboard accessible

## Adding your own content

All content lives in `backend/src/seed/data/`:

- `dsa.js` — the DSA sheet rows
- `tracks.js` — development, core CS, system design and interview topics
- `questions.js` — aptitude, reasoning and core CS quiz questions
- `interview.js` — interview answers and company guides

Add rows, then re-run `npm run seed` in `backend/`.

## Deploying

- Frontend: `npm run build` in `frontend/`, deploy `dist/` to Vercel or Netlify, set `VITE_API_URL` to your API URL
- Backend: deploy to Render or Railway, set the env vars, and set `CLIENT_URL` to your deployed frontend origin
- Database: MongoDB Atlas free tier
