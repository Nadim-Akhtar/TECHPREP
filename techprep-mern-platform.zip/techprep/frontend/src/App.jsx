import { Routes, Route, Navigate } from "react-router-dom";
import Home from "./pages/Home.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import TrackSheet from "./pages/TrackSheet.jsx";
import Quiz from "./pages/Quiz.jsx";
import Interview from "./pages/Interview.jsx";
import Companies from "./pages/Companies.jsx";
import Profile from "./pages/Profile.jsx";
import NotFound from "./pages/NotFound.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

const guard = (element) => <ProtectedRoute>{element}</ProtectedRoute>;

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route path="/dashboard" element={guard(<Dashboard />)} />
      <Route path="/track/:trackKey" element={guard(<TrackSheet />)} />
      <Route path="/quiz/:trackKey" element={guard(<Quiz />)} />
      <Route path="/interview" element={guard(<Interview />)} />
      <Route path="/companies" element={guard(<Companies />)} />
      <Route path="/revision" element={guard(<TrackSheet revisionMode />)} />
      <Route path="/profile" element={guard(<Profile />)} />

      <Route path="/dsa" element={<Navigate to="/track/dsa" replace />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
