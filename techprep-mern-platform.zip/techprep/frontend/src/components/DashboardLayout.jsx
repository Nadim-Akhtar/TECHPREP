import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import {
  LayoutGrid, Code2, Laptop, Calculator, Brain, Database, Network,
  MessagesSquare, Building2, LogOut, ChevronLeft, Search, Bell, Sun, Moon, Star,
} from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";
import { useTheme } from "../context/ThemeContext.jsx";

const nav = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutGrid },
  { to: "/track/dsa", label: "DSA", icon: Code2 },
  { to: "/track/development", label: "Development", icon: Laptop },
  { to: "/quiz/aptitude", label: "Aptitude", icon: Calculator },
  { to: "/quiz/reasoning", label: "Reasoning", icon: Brain },
  { to: "/track/corecs", label: "Core CS", icon: Database },
  { to: "/track/system-design", label: "System Design", icon: Network },
  { to: "/interview", label: "Interview", icon: MessagesSquare },
  { to: "/companies", label: "Companies", icon: Building2 },
  { to: "/revision", label: "Revision", icon: Star },
];

export default function DashboardLayout({ children }) {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <div className="flex min-h-screen bg-zinc-50 dark:bg-ink-900">
      <aside
        className={`sticky top-0 hidden h-screen shrink-0 flex-col justify-between border-r border-zinc-200 bg-white transition-all duration-300 lg:flex dark:border-ink-700 dark:bg-ink-900 ${
          collapsed ? "w-[84px]" : "w-[264px]"
        }`}
      >
        <div>
          <Link to="/" className="flex items-center gap-3 px-5 py-6">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-indigo-500 text-sm font-extrabold text-white">
              T
            </span>
            {!collapsed && (
              <span className="leading-tight">
                <span className="block text-lg font-extrabold">TechPrep</span>
                <span className="block text-[11px] text-zinc-500">Career preparation</span>
              </span>
            )}
          </Link>

          {!collapsed && <p className="px-5 pb-2 text-[11px] font-semibold tracking-wide text-zinc-400">Workspace</p>}

          <nav className="space-y-1 px-3">
            {nav.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                    isActive
                      ? "bg-brand-50 text-brand-700 dark:bg-ink-700 dark:text-brand-300"
                      : "text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-ink-800"
                  }`
                }
                title={collapsed ? label : undefined}
              >
                <Icon size={18} className="shrink-0" />
                {!collapsed && label}
              </NavLink>
            ))}
          </nav>
        </div>

        <div className="space-y-1 px-3 pb-6">
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-zinc-600 transition hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-ink-800"
          >
            <LogOut size={18} />
            {!collapsed && "Log out"}
          </button>
          <button
            onClick={() => setCollapsed((c) => !c)}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-zinc-500 transition hover:bg-zinc-100 dark:hover:bg-ink-800"
          >
            <ChevronLeft size={18} className={collapsed ? "rotate-180 transition" : "transition"} />
            {!collapsed && "Collapse"}
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center gap-4 border-b border-zinc-200 bg-white/90 px-5 py-3 backdrop-blur dark:border-ink-700 dark:bg-ink-900/90">
          <label className="relative hidden flex-1 items-center md:flex">
            <Search size={16} className="absolute left-4 text-zinc-400" />
            <input
              className="field pl-11"
              placeholder="Search topics, questions, companies..."
              onKeyDown={(e) => {
                if (e.key === "Enter" && e.currentTarget.value.trim()) {
                  navigate(`/track/dsa?search=${encodeURIComponent(e.currentTarget.value.trim())}`);
                }
              }}
            />
          </label>

          <div className="ml-auto flex items-center gap-3">
            <button onClick={toggleTheme} className="grid h-10 w-10 place-items-center rounded-full border border-zinc-200 dark:border-ink-600">
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <button className="relative grid h-10 w-10 place-items-center rounded-full border border-zinc-200 dark:border-ink-600" aria-label="Notifications">
              <Bell size={18} />
              <span className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full bg-brand-500" />
            </button>
            <Link to="/profile" className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-brand-500 font-bold text-white">
                {user?.name?.[0]?.toUpperCase() || "U"}
              </span>
              <span className="hidden leading-tight sm:block">
                <span className="block text-sm font-bold">{user?.name}</span>
                <span className="block text-[11px] text-zinc-500">{user?.targetRole || "Student"}</span>
              </span>
            </Link>
          </div>
        </header>

        <main className="min-w-0 flex-1 px-5 py-8 lg:px-10">{children}</main>
      </div>
    </div>
  );
}
