import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { Moon, Sun, Menu, X, ChevronDown } from "lucide-react";
import { useTheme } from "../context/ThemeContext.jsx";
import { useAuth } from "../context/AuthContext.jsx";

const links = [
  { to: "/", label: "Home" },
  { to: "/track/dsa", label: "DSA" },
  { to: "/track/development", label: "Development" },
  { to: "/quiz/aptitude", label: "Aptitude" },
  { to: "/interview", label: "Interview" },
  { to: "/companies", label: "Companies" },
];

export default function Navbar() {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-zinc-200/70 bg-white/80 backdrop-blur-xl dark:border-ink-700 dark:bg-ink-900/80">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-6 px-5 py-3">
        <Link to="/" className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-indigo-500 text-sm font-extrabold text-white">
            TP
          </span>
          <span className="leading-tight">
            <span className="block text-lg font-extrabold tracking-tight">TechPrep</span>
            <span className="block text-[11px] text-zinc-500">Prepare smart. Get hired.</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `rounded-lg px-3 py-2 text-sm font-medium transition ${
                  isActive ? "text-brand-600 dark:text-brand-300" : "text-zinc-600 hover:text-ink-900 dark:text-zinc-300 dark:hover:text-white"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleTheme}
            aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
            className="grid h-10 w-10 place-items-center rounded-full border border-zinc-200 text-zinc-600 transition hover:bg-zinc-50 dark:border-ink-600 dark:text-zinc-300 dark:hover:bg-ink-800"
          >
            {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {user ? (
            <Link to="/dashboard" className="btn-primary hidden sm:inline-flex">
              Dashboard
            </Link>
          ) : (
            <>
              <Link to="/login" className="btn-ghost hidden sm:inline-flex">
                Sign in
              </Link>
              <Link to="/register" className="btn-primary hidden sm:inline-flex">
                Get started
              </Link>
            </>
          )}

          <button className="lg:hidden" onClick={() => setOpen((o) => !o)} aria-label="Toggle menu">
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="border-t border-zinc-200 px-5 py-3 lg:hidden dark:border-ink-700">
          {links.map((l) => (
            <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="block rounded-lg px-2 py-2.5 text-sm font-medium">
              {l.label}
            </Link>
          ))}
          <Link to={user ? "/dashboard" : "/login"} onClick={() => setOpen(false)} className="btn-primary mt-2 w-full">
            {user ? "Go to dashboard" : "Sign in"}
          </Link>
        </nav>
      )}
    </header>
  );
}
