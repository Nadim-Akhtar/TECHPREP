export default function StatCard({ icon: Icon, label, value, caption, tint = "bg-brand-50 text-brand-600" }) {
  return (
    <div className="flex items-start gap-4">
      <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl ${tint} dark:bg-ink-700`}>
        <Icon size={20} />
      </span>
      <div>
        <p className="text-xs font-medium text-zinc-500">{label}</p>
        <p className="text-2xl font-extrabold tracking-tight">{value}</p>
        <p className="text-xs text-zinc-400">{caption}</p>
      </div>
    </div>
  );
}
