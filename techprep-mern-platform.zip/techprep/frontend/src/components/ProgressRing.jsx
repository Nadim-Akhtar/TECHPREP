export default function ProgressRing({ percent = 0, size = 116, stroke = 10, accent = "#7c4dff" }) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.min(percent, 100) / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="currentColor" strokeWidth={stroke} fill="none" className="text-zinc-200 dark:text-ink-600" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={accent}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset .6s cubic-bezier(.2,.7,.3,1)" }}
        />
      </svg>
      <span className="absolute inset-0 grid place-items-center text-xl font-extrabold">{percent}%</span>
    </div>
  );
}

export function ProgressBar({ percent = 0, color = "bg-brand-500" }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-zinc-200 dark:bg-ink-600">
      <div className={`h-full rounded-full ${color} transition-all duration-500`} style={{ width: `${percent}%` }} />
    </div>
  );
}
