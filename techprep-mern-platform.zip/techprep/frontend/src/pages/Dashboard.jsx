import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Flame, Clock, CheckCircle2, Target, ArrowUpRight, Code2, Laptop, Calculator, Database, Network, MessagesSquare } from "lucide-react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import StatCard from "../components/StatCard.jsx";
import { ProgressBar } from "../components/ProgressRing.jsx";
import Loader from "../components/Loader.jsx";
import api from "../api/client.js";
import { useAuth } from "../context/AuthContext.jsx";

const trackMeta = {
  dsa: { icon: Code2, to: "/track/dsa", bar: "bg-brand-500", tint: "bg-brand-50 text-brand-600" },
  development: { icon: Laptop, to: "/track/development", bar: "bg-blue-500", tint: "bg-blue-50 text-blue-600" },
  aptitude: { icon: Calculator, to: "/quiz/aptitude", bar: "bg-orange-500", tint: "bg-orange-50 text-orange-600" },
  corecs: { icon: Database, to: "/track/corecs", bar: "bg-emerald-500", tint: "bg-emerald-50 text-emerald-600" },
  "system-design": { icon: Network, to: "/track/system-design", bar: "bg-pink-500", tint: "bg-pink-50 text-pink-600" },
  interview: { icon: MessagesSquare, to: "/interview", bar: "bg-violet-500", tint: "bg-violet-50 text-violet-600" },
};

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/progress/summary")
      .then((res) => setData(res.data))
      .catch((err) => setError(err.message));
  }, []);

  if (error) return <DashboardLayout><p className="text-sm text-red-600">{error}</p></DashboardLayout>;
  if (!data) return <DashboardLayout><Loader label="Loading your progress" /></DashboardLayout>;

  const { stats, tracks, recent, attempts } = data;

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-6xl animate-rise">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-xs font-semibold text-brand-600 dark:text-brand-300">Your learning hub</p>
            <h1 className="mt-2 text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">
              Keep learning,
              <span className="block text-brand-500">keep growing.</span>
            </h1>
            <p className="mt-3 max-w-lg text-zinc-600 dark:text-zinc-400">
              Build your skills, practise consistently and get ready for your dream placement.
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-zinc-500">Daily goal</p>
            <p className="text-4xl font-extrabold tracking-tight">{stats.dailyGoalMinutes} min</p>
            <p className="text-xs text-zinc-400">Stay consistent today</p>
          </div>
        </div>

        <div className="mt-12 grid gap-8 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard icon={Flame} label="Current streak" value={`${stats.streak} days`} caption="Keep it going" tint="bg-brand-50 text-brand-600" />
          <StatCard icon={Clock} label="Learning time" value={`${(stats.minutesLearned / 60).toFixed(1)} hrs`} caption="All time" tint="bg-blue-50 text-blue-600" />
          <StatCard icon={CheckCircle2} label="Topics completed" value={stats.topicsCompleted} caption="Across all tracks" tint="bg-emerald-50 text-emerald-600" />
          <StatCard icon={Target} label="Overall progress" value={`${stats.overallPercent}%`} caption="Keep improving" tint="bg-orange-50 text-orange-600" />
        </div>

        <section className="mt-16">
          <p className="text-xs font-semibold text-brand-600 dark:text-brand-300">Your roadmap</p>
          <h2 className="mt-2 text-3xl font-extrabold tracking-tight">Preparation tracks</h2>

          <div className="mt-8 grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
            {tracks.map((t) => {
              const meta = trackMeta[t.key] || trackMeta.dsa;
              const Icon = meta.icon;
              return (
                <Link key={t.key} to={meta.to} className="card group p-6 transition hover:-translate-y-0.5 hover:border-brand-300">
                  <div className="flex items-start justify-between">
                    <span className={`grid h-12 w-12 place-items-center rounded-2xl ${meta.tint} dark:bg-ink-700`}>
                      <Icon size={20} />
                    </span>
                    <ArrowUpRight size={18} className="text-zinc-400 transition group-hover:text-brand-500" />
                  </div>
                  <h3 className="mt-6 text-lg font-bold leading-snug">{t.title}</h3>
                  <p className="mt-2 text-sm text-zinc-500">{t.blurb}</p>
                  <div className="mt-8 flex items-center justify-between text-xs font-medium text-zinc-500">
                    <span>{t.solved}/{t.total} topics</span>
                    <span className="font-bold text-ink-900 dark:text-zinc-100">{t.percent}%</span>
                  </div>
                  <div className="mt-2">
                    <ProgressBar percent={t.percent} color={meta.bar} />
                  </div>
                </Link>
              );
            })}
          </div>
        </section>

        <div className="mt-16 grid gap-6 lg:grid-cols-2">
          <section className="card p-6">
            <h2 className="text-lg font-bold">Recently solved</h2>
            {recent.length === 0 ? (
              <p className="mt-6 text-sm text-zinc-500">
                Nothing ticked off yet. <Link to="/track/dsa" className="font-semibold text-brand-600">Start with the DSA basics.</Link>
              </p>
            ) : (
              <ul className="mt-5 divide-y divide-zinc-100 dark:divide-ink-700">
                {recent.map((r) => (
                  <li key={r._id} className="flex items-center justify-between gap-4 py-3">
                    <span className="truncate text-sm font-medium">{r.problem?.title}</span>
                    <span className="chip bg-zinc-100 text-zinc-600 dark:bg-ink-700 dark:text-zinc-300">{r.problem?.difficulty}</span>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="card p-6">
            <h2 className="text-lg font-bold">Latest quiz attempts</h2>
            {attempts.length === 0 ? (
              <p className="mt-6 text-sm text-zinc-500">
                No attempts yet. <Link to="/quiz/aptitude" className="font-semibold text-brand-600">Take a 10-question aptitude quiz.</Link>
              </p>
            ) : (
              <ul className="mt-5 divide-y divide-zinc-100 dark:divide-ink-700">
                {attempts.map((a) => (
                  <li key={a._id} className="flex items-center justify-between gap-4 py-3 text-sm">
                    <span className="font-medium capitalize">{a.track} · {a.topic}</span>
                    <span className="font-bold">{a.correct}/{a.total}</span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        <p className="mt-10 text-center text-xs text-zinc-400">Signed in as {user?.email}</p>
      </div>
    </DashboardLayout>
  );
}
