import { useEffect, useState } from "react";
import { ChevronDown, Search } from "lucide-react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import Loader from "../components/Loader.jsx";
import api from "../api/client.js";

const categories = ["all", "HR", "Behavioural", "Technical", "System Design"];

export default function Interview() {
  const [questions, setQuestions] = useState(null);
  const [category, setCategory] = useState("all");
  const [search, setSearch] = useState("");
  const [openId, setOpenId] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/content/interview", { params: { category } })
      .then((r) => setQuestions(r.data.questions))
      .catch((err) => setError(err.message));
  }, [category]);

  const visible = questions?.filter((q) => q.question.toLowerCase().includes(search.toLowerCase()));

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-4xl animate-rise">
        <h1 className="text-4xl font-extrabold tracking-tight">Interview preparation</h1>
        <p className="mt-2 max-w-2xl text-zinc-600 dark:text-zinc-400">
          Answer frameworks for the rounds that decide the offer. Read the structure, then say it in your own words.
        </p>

        <div className="mt-8 flex flex-wrap gap-3">
          <label className="relative flex min-w-[240px] flex-1 items-center">
            <Search size={16} className="absolute left-4 text-zinc-400" />
            <input className="field pl-11" placeholder="Search questions..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </label>
          <div className="flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
                  category === c ? "bg-brand-500 text-white" : "border border-zinc-200 text-zinc-600 dark:border-ink-600 dark:text-zinc-300"
                }`}
              >
                {c === "all" ? "All" : c}
              </button>
            ))}
          </div>
        </div>

        {error && <p className="mt-6 text-sm text-red-600">{error}</p>}
        {!questions && <Loader label="Loading questions" />}

        <div className="mt-8 space-y-3">
          {visible?.map((q) => (
            <div key={q._id} className="card overflow-hidden">
              <button className="flex w-full items-center gap-4 px-6 py-5 text-left" onClick={() => setOpenId(openId === q._id ? null : q._id)}>
                <span className="chip bg-brand-50 text-brand-700 dark:bg-ink-700 dark:text-brand-300">{q.category}</span>
                <span className="flex-1 font-semibold">{q.question}</span>
                <ChevronDown size={18} className={`shrink-0 transition ${openId === q._id ? "rotate-180" : ""}`} />
              </button>

              {openId === q._id && (
                <div className="border-t border-zinc-100 px-6 py-5 dark:border-ink-700">
                  <p className="leading-relaxed text-zinc-700 dark:text-zinc-300">{q.answer}</p>
                  {q.tips?.length > 0 && (
                    <ul className="mt-4 space-y-2">
                      {q.tips.map((t) => (
                        <li key={t} className="flex gap-2 text-sm text-zinc-600 dark:text-zinc-400">
                          <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-500" />
                          {t}
                        </li>
                      ))}
                    </ul>
                  )}
                  {q.companies?.length > 0 && (
                    <p className="mt-4 text-xs text-zinc-500">Asked at: {q.companies.join(", ")}</p>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
