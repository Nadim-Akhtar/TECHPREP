import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams, useSearchParams, Link } from "react-router-dom";
import { ChevronDown, FileText, PlayCircle, Plus, Star, Shuffle, RotateCcw, Search, ArrowLeft, X } from "lucide-react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import ProgressRing, { ProgressBar } from "../components/ProgressRing.jsx";
import Loader, { EmptyState } from "../components/Loader.jsx";
import api from "../api/client.js";

const TRACK_TITLES = {
  dsa: { title: "Data Structures & Algorithms", blurb: "Learn concepts, read articles, practise problems and revise important interview patterns in one place." },
  development: { title: "Full Stack Development", blurb: "Go from HTML and JavaScript to React, Node, Express and MongoDB, ending with projects you can ship." },
  corecs: { title: "Core Computer Science", blurb: "OS, DBMS, Computer Networks and OOPs, written the way interviewers actually ask them." },
  "system-design": { title: "System Design", blurb: "Low level design case studies and the high level building blocks behind real products." },
  interview: { title: "Interview Preparation", blurb: "Resume, rounds and answer frameworks that hold up under follow-up questions." },
};

const difficultyChip = {
  Easy: "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400",
  Medium: "bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-400",
  Hard: "bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-400",
};

function NoteModal({ problem, onClose, onSaved }) {
  const [text, setText] = useState(problem.note || "");
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true);
    try {
      await api.put(`/progress/${problem._id}/note`, { note: text });
      onSaved(problem._id, text);
      onClose();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 px-5" onClick={onClose}>
      <div className="card w-full max-w-lg p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold">Note</h3>
            <p className="text-sm text-zinc-500">{problem.title}</p>
          </div>
          <button onClick={onClose} aria-label="Close note"><X size={18} /></button>
        </div>
        <textarea
          className="field mt-4 h-44 resize-none"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Approach, edge cases, the trick you keep forgetting..."
        />
        <div className="mt-4 flex justify-end gap-2">
          <button className="btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn-primary" onClick={save} disabled={busy}>{busy ? "Saving..." : "Save note"}</button>
        </div>
      </div>
    </div>
  );
}

export default function TrackSheet({ revisionMode = false }) {
  const { trackKey = "dsa" } = useParams();
  const track = revisionMode ? "dsa" : trackKey;
  const [searchParams, setSearchParams] = useSearchParams();

  const [roadmap, setRoadmap] = useState(null);
  const [error, setError] = useState("");
  const [open, setOpen] = useState({});
  const [search, setSearch] = useState(searchParams.get("search") || "");
  const [topic, setTopic] = useState("all");
  const [difficulty, setDifficulty] = useState("all");
  const [showRevisionOnly, setShowRevisionOnly] = useState(revisionMode);
  const [noteFor, setNoteFor] = useState(null);

  const meta = TRACK_TITLES[track] || TRACK_TITLES.dsa;

  const load = useCallback(async () => {
    setRoadmap(null);
    try {
      const { data } = await api.get("/problems/roadmap", { params: { track } });
      setRoadmap(data);
      setOpen(Object.fromEntries(data.sections.map((s, i) => [s.name, i === 0])));
    } catch (err) {
      setError(err.message);
    }
  }, [track]);

  useEffect(() => { load(); }, [load]);

  const allTopics = useMemo(() => {
    if (!roadmap) return [];
    return [...new Set(roadmap.sections.flatMap((s) => s.topics.map((t) => t.name)))];
  }, [roadmap]);

  const patch = (problemId, changes) => {
    setRoadmap((prev) => {
      if (!prev) return prev;
      const sections = prev.sections.map((s) => {
        const topics = s.topics.map((t) => {
          const problems = t.problems.map((p) => (p._id === problemId ? { ...p, ...changes } : p));
          const solved = problems.filter((p) => p.solved).length;
          return { ...t, problems, solved };
        });
        return { ...s, topics, solved: topics.reduce((a, t) => a + t.solved, 0) };
      });
      const solvedIds = sections.flatMap((s) => s.topics.flatMap((t) => t.problems)).filter((p) => p.solved);
      const byDifficulty = ["Easy", "Medium", "Hard"].map((d) => ({
        difficulty: d,
        total: prev.byDifficulty.find((b) => b.difficulty === d)?.total || 0,
        solved: solvedIds.filter((p) => p.difficulty === d).length,
      }));
      return { ...prev, sections, byDifficulty, totals: { ...prev.totals, solved: solvedIds.length } };
    });
  };

  const toggleSolved = async (p) => {
    patch(p._id, { solved: !p.solved });
    try {
      await api.patch(`/progress/${p._id}/solve`);
    } catch (err) {
      patch(p._id, { solved: p.solved });
      setError(err.message);
    }
  };

  const toggleRevision = async (p) => {
    patch(p._id, { markedForRevision: !p.markedForRevision });
    try {
      await api.patch(`/progress/${p._id}/revision`);
    } catch (err) {
      patch(p._id, { markedForRevision: p.markedForRevision });
      setError(err.message);
    }
  };

  const pickRandom = () => {
    const pool = roadmap.sections.flatMap((s) => s.topics.flatMap((t) => t.problems)).filter((p) => !p.solved);
    if (!pool.length) return;
    const pick = pool[Math.floor(Math.random() * pool.length)];
    setSearch(pick.title);
    setOpen((o) => ({ ...o, [pick.section]: true }));
  };

  const resetFilters = () => {
    setSearch("");
    setTopic("all");
    setDifficulty("all");
    setShowRevisionOnly(revisionMode);
    setSearchParams({});
  };

  const matches = (p) =>
    (!search || p.title.toLowerCase().includes(search.toLowerCase())) &&
    (topic === "all" || p.topic === topic) &&
    (difficulty === "all" || p.difficulty === difficulty) &&
    (!showRevisionOnly || p.markedForRevision);

  if (error && !roadmap) return <DashboardLayout><p className="text-sm text-red-600">{error}</p></DashboardLayout>;
  if (!roadmap) return <DashboardLayout><Loader label="Loading the roadmap" /></DashboardLayout>;

  const percent = roadmap.totals.total ? Math.round((roadmap.totals.solved / roadmap.totals.total) * 100) : 0;
  const visibleSections = roadmap.sections
    .map((s) => ({ ...s, topics: s.topics.map((t) => ({ ...t, problems: t.problems.filter(matches) })).filter((t) => t.problems.length) }))
    .filter((s) => s.topics.length);

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-6xl animate-rise">
        <Link to="/dashboard" className="inline-flex items-center gap-2 text-sm font-medium text-zinc-500 hover:text-brand-600">
          <ArrowLeft size={16} /> Back to dashboard
        </Link>

        <div className="mt-4 flex flex-wrap items-start justify-between gap-6">
          <div>
            <h1 className="text-4xl font-extrabold tracking-tight">{revisionMode ? "Revision list" : meta.title}</h1>
            <p className="mt-2 max-w-2xl text-zinc-600 dark:text-zinc-400">
              {revisionMode ? "Everything you starred for a second pass, all in one place." : meta.blurb}
            </p>
          </div>
          {!revisionMode && (
            <div className="flex rounded-xl border border-zinc-200 p-1 dark:border-ink-600">
              <button
                onClick={() => setShowRevisionOnly(false)}
                className={`rounded-lg px-4 py-2 text-sm font-semibold ${!showRevisionOnly ? "bg-ink-900 text-white dark:bg-ink-700" : "text-zinc-500"}`}
              >
                All problems
              </button>
              <button
                onClick={() => setShowRevisionOnly(true)}
                className={`rounded-lg px-4 py-2 text-sm font-semibold ${showRevisionOnly ? "bg-ink-900 text-white dark:bg-ink-700" : "text-zinc-500"}`}
              >
                Revision
              </button>
            </div>
          )}
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <label className="relative flex min-w-[240px] flex-1 items-center">
            <Search size={16} className="absolute left-4 text-zinc-400" />
            <input className="field pl-11" placeholder="Search problems..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </label>
          <select className="field w-auto" value={topic} onChange={(e) => setTopic(e.target.value)}>
            <option value="all">All topics</option>
            {allTopics.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <select className="field w-auto" value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
            <option value="all">All difficulties</option>
            <option>Easy</option>
            <option>Medium</option>
            <option>Hard</option>
          </select>
          <button className="btn-ghost" onClick={pickRandom}><Shuffle size={16} /> Random</button>
          <button className="btn-ghost" onClick={resetFilters}><RotateCcw size={16} /> Reset</button>
        </div>

        <section className="card mt-6 flex flex-wrap items-center gap-10 p-7">
          <ProgressRing percent={percent} />
          <div>
            <p className="text-sm text-zinc-500">Overall progress</p>
            <p className="text-3xl font-extrabold">
              {roadmap.totals.solved} <span className="text-zinc-400">/ {roadmap.totals.total}</span>
            </p>
            <p className="mt-1 text-xs text-zinc-400">Keep practising every day.</p>
          </div>
          <div className="ml-auto flex flex-wrap gap-10">
            {roadmap.byDifficulty.map((d) => (
              <div key={d.difficulty}>
                <p className="flex items-center gap-2 text-sm font-semibold">
                  <span className={`h-2.5 w-2.5 rounded-full ${d.difficulty === "Easy" ? "bg-emerald-500" : d.difficulty === "Medium" ? "bg-amber-500" : "bg-rose-500"}`} />
                  {d.difficulty}
                </p>
                <p className="mt-1 text-xl font-extrabold">
                  {d.solved} <span className="text-zinc-400">/ {d.total}</span>
                </p>
              </div>
            ))}
          </div>
        </section>

        <section className="card mt-6 overflow-hidden">
          <div className="flex items-center justify-between border-b border-zinc-100 px-7 py-6 dark:border-ink-700">
            <div>
              <h2 className="text-xl font-bold">Learning roadmap</h2>
              <p className="text-sm text-zinc-500">Follow topics in a structured order.</p>
            </div>
            <span className="text-sm text-zinc-500">{roadmap.totals.total} problems</span>
          </div>

          {visibleSections.length === 0 ? (
            <EmptyState
              title={showRevisionOnly ? "Nothing starred yet" : "No problems match these filters"}
              hint={showRevisionOnly ? "Star a problem from the roadmap to build your revision list." : "Try clearing the search or difficulty filter."}
              action={<button className="btn-ghost mt-2" onClick={resetFilters}>Reset filters</button>}
            />
          ) : (
            visibleSections.map((section) => (
              <div key={section.name} className="border-b border-zinc-100 last:border-0 dark:border-ink-700">
                <button
                  className="flex w-full items-center gap-4 px-7 py-5 text-left"
                  onClick={() => setOpen((o) => ({ ...o, [section.name]: !o[section.name] }))}
                >
                  <ChevronDown size={18} className={`shrink-0 transition ${open[section.name] ? "" : "-rotate-90"}`} />
                  <span className="flex-1">
                    <span className="block text-lg font-bold">{section.name}</span>
                    <span className="block text-sm text-zinc-500">{section.topics.length} topics</span>
                  </span>
                  <span className="hidden w-40 sm:block"><ProgressBar percent={section.total ? Math.round((section.solved / section.total) * 100) : 0} /></span>
                  <span className="w-16 text-right text-sm font-semibold text-zinc-500">{section.solved}/{section.total}</span>
                </button>

                {open[section.name] &&
                  section.topics.map((t) => (
                    <div key={t.name} className="bg-zinc-50/60 dark:bg-ink-800/60">
                      <div className="flex items-center justify-between px-7 py-4 pl-14">
                        <h3 className="font-semibold">{t.name}</h3>
                        <span className="text-xs text-zinc-500">{t.problems.length} problems</span>
                      </div>

                      <div className="overflow-x-auto scroll-thin">
                        <table className="w-full min-w-[820px] text-sm">
                          <thead className="text-left text-xs font-semibold text-zinc-500">
                            <tr className="border-y border-zinc-200/70 dark:border-ink-700">
                              <th className="py-3 pl-14 pr-3">Status</th>
                              <th className="px-3">Problem</th>
                              <th className="px-3">Article</th>
                              <th className="px-3">Video</th>
                              <th className="px-3">Note</th>
                              <th className="px-3">Revision</th>
                              <th className="px-3">Difficulty</th>
                            </tr>
                          </thead>
                          <tbody>
                            {t.problems.map((p) => (
                              <tr key={p._id} className="border-b border-zinc-100 transition hover:bg-white dark:border-ink-700 dark:hover:bg-ink-800">
                                <td className="py-3.5 pl-14 pr-3">
                                  <input
                                    type="checkbox"
                                    checked={p.solved}
                                    onChange={() => toggleSolved(p)}
                                    aria-label={`Mark ${p.title} as solved`}
                                    className="h-[18px] w-[18px] cursor-pointer accent-brand-500"
                                  />
                                </td>
                                <td className={`px-3 font-semibold ${p.solved ? "text-zinc-400 line-through" : ""}`}>{p.title}</td>
                                <td className="px-3">
                                  {p.articleUrl ? (
                                    <a href={p.articleUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 font-medium text-brand-600 dark:text-brand-300">
                                      <FileText size={15} /> Read
                                    </a>
                                  ) : <span className="text-zinc-400">—</span>}
                                </td>
                                <td className="px-3">
                                  {p.videoUrl ? (
                                    <a href={p.videoUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-zinc-600 dark:text-zinc-300">
                                      <PlayCircle size={15} /> Watch
                                    </a>
                                  ) : <span className="text-zinc-400">—</span>}
                                </td>
                                <td className="px-3">
                                  <button onClick={() => setNoteFor(p)} aria-label={`Add note to ${p.title}`} className={p.note ? "text-brand-500" : "text-zinc-400 hover:text-brand-500"}>
                                    <Plus size={18} />
                                  </button>
                                </td>
                                <td className="px-3">
                                  <button onClick={() => toggleRevision(p)} aria-label={`Star ${p.title} for revision`}>
                                    <Star size={18} className={p.markedForRevision ? "fill-amber-400 text-amber-400" : "text-zinc-400 hover:text-amber-400"} />
                                  </button>
                                </td>
                                <td className="px-3">
                                  <span className={`chip ${difficultyChip[p.difficulty]}`}>{p.difficulty}</span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ))}
              </div>
            ))
          )}
        </section>
      </div>

      {noteFor && (
        <NoteModal
          problem={noteFor}
          onClose={() => setNoteFor(null)}
          onSaved={(id, note) => patch(id, { note })}
        />
      )}
    </DashboardLayout>
  );
}
