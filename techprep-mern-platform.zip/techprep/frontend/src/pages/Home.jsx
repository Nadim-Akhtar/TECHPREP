import { Link } from "react-router-dom";
import { ArrowRight, Code2, Target, Sparkles, Laptop, Calculator, Database, Network, MessagesSquare, Building2 } from "lucide-react";
import Navbar from "../components/Navbar.jsx";
import { useAuth } from "../context/AuthContext.jsx";

const tracks = [
  { icon: Code2, title: "Data Structures & Algorithms", text: "92 curated problems from basics to graphs and DP, with notes and revision marks.", to: "/track/dsa" },
  { icon: Laptop, title: "Full Stack Development", text: "JavaScript, React, Node, Express and MongoDB, ending in projects you can ship.", to: "/track/development" },
  { icon: Calculator, title: "Aptitude & Reasoning", text: "Timed quizzes with instant explanations for every company assessment round.", to: "/quiz/aptitude" },
  { icon: Database, title: "Core Computer Science", text: "OS, DBMS, Networks and OOPs, written the way interviewers ask them.", to: "/track/corecs" },
  { icon: Network, title: "System Design", text: "LLD case studies and HLD building blocks, from parking lots to news feeds.", to: "/track/system-design" },
  { icon: MessagesSquare, title: "Interview Preparation", text: "Answer frameworks for HR, behavioural and technical rounds.", to: "/interview" },
];

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen">
      <Navbar />

      <section className="relative overflow-hidden px-5 pb-24 pt-20">
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-[640px] opacity-70 dark:opacity-30"
          style={{ background: "radial-gradient(60% 55% at 50% 0%, #e9e2ff 0%, rgba(255,255,255,0) 70%)" }}
        />
        <div className="relative mx-auto max-w-4xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-4 py-1.5 text-xs font-semibold text-brand-700 dark:border-ink-600 dark:bg-ink-800 dark:text-brand-300">
            <Sparkles size={14} /> Your complete CSE placement preparation platform
          </span>

          <h1 className="mt-8 text-5xl font-extrabold leading-[1.05] tracking-tight sm:text-7xl">
            Prepare smart.
            <span className="mt-1 block bg-gradient-to-r from-brand-400 to-indigo-400 bg-clip-text text-transparent">
              Get hired.
            </span>
          </h1>

          <p className="mx-auto mt-7 max-w-2xl text-lg text-zinc-600 dark:text-zinc-400">
            DSA, development, aptitude, reasoning, core CS, system design and interviews — one place, one
            progress bar, no more twenty open tabs.
          </p>

          <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
            <Link to={user ? "/dashboard" : "/register"} className="btn-primary px-7 py-3.5 text-base">
              Start learning <ArrowRight size={18} />
            </Link>
            <Link to="/track/dsa" className="btn-ghost px-7 py-3.5 text-base">
              <Target size={18} /> Explore the roadmap
            </Link>
          </div>

          <dl className="mx-auto mt-16 grid max-w-2xl grid-cols-2 gap-8 sm:grid-cols-4">
            {[
              ["180+", "topics and problems"],
              ["44", "quiz questions"],
              ["8", "company guides"],
              ["7", "preparation tracks"],
            ].map(([value, label]) => (
              <div key={label}>
                <dt className="text-3xl font-extrabold tracking-tight">{value}</dt>
                <dd className="mt-1 text-xs text-zinc-500">{label}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-24">
        <h2 className="text-3xl font-extrabold tracking-tight">Everything a placement season asks for</h2>
        <p className="mt-2 max-w-xl text-zinc-600 dark:text-zinc-400">
          Each track tracks itself. Tick a topic, leave a note, star it for revision later.
        </p>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {tracks.map(({ icon: Icon, title, text, to }) => (
            <Link key={title} to={to} className="card group p-6 transition hover:border-brand-300">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-50 text-brand-600 dark:bg-ink-700 dark:text-brand-300">
                <Icon size={22} />
              </span>
              <h3 className="mt-5 text-lg font-bold">{title}</h3>
              <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-400">{text}</p>
              <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-600 dark:text-brand-300">
                Open track <ArrowRight size={15} className="transition group-hover:translate-x-1" />
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="border-y border-zinc-200 bg-zinc-50 px-5 py-20 dark:border-ink-700 dark:bg-ink-800">
        <div className="mx-auto max-w-5xl">
          <h2 className="text-3xl font-extrabold tracking-tight">How students use TechPrep</h2>
          <ol className="mt-10 grid gap-8 md:grid-cols-3">
            {[
              ["Pick a track", "Start with the DSA roadmap or jump straight to the company you are targeting."],
              ["Practise daily", "Tick problems off, save notes, and star the ones that need a second pass."],
              ["Revise before the round", "Your revision list and quiz history tell you exactly what to review."],
            ].map(([title, text], i) => (
              <li key={title}>
                <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-500 text-sm font-bold text-white">{i + 1}</span>
                <h3 className="mt-4 font-bold">{title}</h3>
                <p className="mt-1 text-sm text-zinc-600 dark:text-zinc-400">{text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-5 py-24 text-center">
        <Building2 className="mx-auto text-brand-500" size={28} />
        <h2 className="mt-5 text-4xl font-extrabold tracking-tight">Your next offer starts with the problem you solve today</h2>
        <p className="mx-auto mt-4 max-w-xl text-zinc-600 dark:text-zinc-400">
          Create a free account and your progress saves across every track.
        </p>
        <Link to={user ? "/dashboard" : "/register"} className="btn-primary mt-8 px-8 py-3.5 text-base">
          {user ? "Go to dashboard" : "Create free account"}
        </Link>
      </section>

      <footer className="border-t border-zinc-200 px-5 py-8 text-center text-sm text-zinc-500 dark:border-ink-700">
        TechPrep — built with React, Node, Express and MongoDB.
      </footer>
    </div>
  );
}
