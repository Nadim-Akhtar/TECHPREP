import { useEffect, useState } from "react";
import { Search, ArrowLeft } from "lucide-react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import Loader from "../components/Loader.jsx";
import api from "../api/client.js";

const tone = {
  Easy: "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400",
  Medium: "bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-400",
  Hard: "bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-400",
};

export default function Companies() {
  const [companies, setCompanies] = useState(null);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get("/content/companies").then((r) => setCompanies(r.data.companies)).catch((err) => setError(err.message));
  }, []);

  if (error) return <DashboardLayout><p className="text-sm text-red-600">{error}</p></DashboardLayout>;
  if (!companies) return <DashboardLayout><Loader label="Loading company guides" /></DashboardLayout>;

  if (selected) {
    return (
      <DashboardLayout>
        <div className="mx-auto max-w-3xl animate-rise">
          <button onClick={() => setSelected(null)} className="inline-flex items-center gap-2 text-sm font-medium text-zinc-500 hover:text-brand-600">
            <ArrowLeft size={16} /> All companies
          </button>

          <div className="mt-5 flex items-center gap-5">
            <span className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-indigo-500 text-lg font-extrabold text-white">
              {selected.logoText}
            </span>
            <div>
              <h1 className="text-3xl font-extrabold tracking-tight">{selected.name}</h1>
              <p className="text-sm text-zinc-500">{selected.role} · {selected.ctc}</p>
            </div>
            <span className={`chip ml-auto ${tone[selected.difficulty]}`}>{selected.difficulty}</span>
          </div>

          <section className="card mt-8 p-7">
            <h2 className="text-lg font-bold">Hiring rounds</h2>
            <ol className="mt-5 space-y-5">
              {selected.rounds.map((r, i) => (
                <li key={r.name} className="flex gap-4">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand-50 text-sm font-bold text-brand-700 dark:bg-ink-700 dark:text-brand-300">
                    {i + 1}
                  </span>
                  <div>
                    <p className="font-semibold">{r.name}</p>
                    <p className="text-sm text-zinc-500">{r.detail}</p>
                  </div>
                </li>
              ))}
            </ol>
          </section>

          <div className="mt-6 grid gap-6 sm:grid-cols-2">
            <section className="card p-7">
              <h2 className="text-lg font-bold">Focus areas</h2>
              <div className="mt-4 flex flex-wrap gap-2">
                {selected.focusAreas.map((f) => (
                  <span key={f} className="chip bg-zinc-100 text-zinc-700 dark:bg-ink-700 dark:text-zinc-300">{f}</span>
                ))}
              </div>
            </section>
            <section className="card p-7">
              <h2 className="text-lg font-bold">Frequently asked problems</h2>
              <ul className="mt-4 space-y-2 text-sm text-zinc-600 dark:text-zinc-400">
                {selected.topProblems.map((p) => (
                  <li key={p} className="flex gap-2">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-500" />
                    {p}
                  </li>
                ))}
              </ul>
            </section>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  const visible = companies.filter((c) => c.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-5xl animate-rise">
        <h1 className="text-4xl font-extrabold tracking-tight">Company guides</h1>
        <p className="mt-2 max-w-2xl text-zinc-600 dark:text-zinc-400">
          Round structure, focus areas and the problems that keep coming back.
        </p>

        <label className="relative mt-8 flex max-w-md items-center">
          <Search size={16} className="absolute left-4 text-zinc-400" />
          <input className="field pl-11" placeholder="Search companies..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </label>

        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((c) => (
            <button key={c._id} onClick={() => setSelected(c)} className="card p-6 text-left transition hover:-translate-y-0.5 hover:border-brand-300">
              <div className="flex items-start justify-between">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-indigo-500 text-sm font-extrabold text-white">
                  {c.logoText}
                </span>
                <span className={`chip ${tone[c.difficulty]}`}>{c.difficulty}</span>
              </div>
              <h2 className="mt-5 text-lg font-bold">{c.name}</h2>
              <p className="text-sm text-zinc-500">{c.role}</p>
              <p className="mt-3 text-sm font-semibold">{c.ctc}</p>
              <p className="mt-3 text-xs text-zinc-500">{c.rounds.length} rounds · {c.focusAreas.length} focus areas</p>
            </button>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
