import { useCallback, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Timer, RefreshCcw, CheckCircle2, XCircle } from "lucide-react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import Loader from "../components/Loader.jsx";
import api from "../api/client.js";

const TITLES = {
  aptitude: { title: "Quantitative Aptitude", blurb: "Percentages, time and work, speed, interest and more — timed, with worked explanations." },
  reasoning: { title: "Logical Reasoning", blurb: "Series, coding-decoding, blood relations, syllogisms and seating arrangements." },
  corecs: { title: "Core CS Quiz", blurb: "Rapid-fire questions on OS, DBMS, Networks and OOPs." },
};

export default function Quiz() {
  const { trackKey = "aptitude" } = useParams();
  const meta = TITLES[trackKey] || TITLES.aptitude;

  const [topics, setTopics] = useState([]);
  const [topic, setTopic] = useState("all");
  const [limit, setLimit] = useState(10);
  const [questions, setQuestions] = useState(null);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [seconds, setSeconds] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get("/questions/topics", { params: { track: trackKey } }).then((r) => setTopics(r.data)).catch(() => {});
    setQuestions(null);
    setResult(null);
    setAnswers({});
    setTopic("all");
  }, [trackKey]);

  useEffect(() => {
    if (!questions || result) return undefined;
    const id = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, [questions, result]);

  const start = useCallback(async () => {
    setError("");
    setBusy(true);
    setResult(null);
    setAnswers({});
    setSeconds(0);
    try {
      const { data } = await api.get("/questions", { params: { track: trackKey, topic, limit } });
      setQuestions(data.questions);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }, [trackKey, topic, limit]);

  const submit = async () => {
    setBusy(true);
    setError("");
    try {
      const payload = {
        track: trackKey,
        topic: topic === "all" ? "Mixed" : topic,
        timeTakenSec: seconds,
        answers: Object.entries(answers).map(([questionId, chosen]) => ({ questionId, chosen })),
      };
      const { data } = await api.post("/questions/submit", payload);
      setResult(data);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const mmss = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  const reviewFor = (id) => result?.review.find((r) => r.question === id);

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-3xl animate-rise">
        <h1 className="text-4xl font-extrabold tracking-tight">{meta.title}</h1>
        <p className="mt-2 text-zinc-600 dark:text-zinc-400">{meta.blurb}</p>

        {error && <p className="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300">{error}</p>}

        <div className="card mt-8 flex flex-wrap items-end gap-4 p-6">
          <label className="flex-1">
            <span className="mb-1.5 block text-sm font-medium">Topic</span>
            <select className="field" value={topic} onChange={(e) => setTopic(e.target.value)}>
              <option value="all">All topics</option>
              {topics.map((t) => <option key={t.topic} value={t.topic}>{t.topic} ({t.count})</option>)}
            </select>
          </label>
          <label>
            <span className="mb-1.5 block text-sm font-medium">Questions</span>
            <select className="field w-auto" value={limit} onChange={(e) => setLimit(Number(e.target.value))}>
              {[5, 10, 15, 20].map((n) => <option key={n} value={n}>{n}</option>)}
            </select>
          </label>
          <button className="btn-primary py-3" onClick={start} disabled={busy}>
            {questions ? <><RefreshCcw size={16} /> New quiz</> : "Start quiz"}
          </button>
          {questions && !result && (
            <span className="ml-auto inline-flex items-center gap-2 text-sm font-semibold text-zinc-500">
              <Timer size={16} /> {mmss}
            </span>
          )}
        </div>

        {busy && !questions && <Loader label="Pulling questions" />}

        {result && (
          <div className="card mt-6 p-7 text-center">
            <p className="text-sm text-zinc-500">Your score</p>
            <p className="mt-1 text-5xl font-extrabold tracking-tight">{result.score}%</p>
            <p className="mt-2 text-sm text-zinc-500">
              {result.correct} of {result.total} correct in {mmss}
            </p>
            <button className="btn-primary mt-6" onClick={start}>Try another set</button>
          </div>
        )}

        {questions?.map((q, i) => {
          const review = reviewFor(q._id);
          return (
            <div key={q._id} className="card mt-5 p-6">
              <div className="flex gap-3">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-zinc-100 text-xs font-bold dark:bg-ink-700">{i + 1}</span>
                <p className="font-semibold leading-relaxed">{q.question}</p>
              </div>

              <div className="mt-4 space-y-2 pl-10">
                {q.options.map((opt, idx) => {
                  const chosen = answers[q._id] === idx;
                  let tone = "border-zinc-200 dark:border-ink-600";
                  if (review) {
                    if (idx === review.correctIndex) tone = "border-emerald-400 bg-emerald-50 dark:bg-emerald-950/30";
                    else if (chosen) tone = "border-rose-400 bg-rose-50 dark:bg-rose-950/30";
                  } else if (chosen) {
                    tone = "border-brand-400 bg-brand-50 dark:bg-ink-700";
                  }
                  return (
                    <button
                      key={idx}
                      disabled={!!result}
                      onClick={() => setAnswers((a) => ({ ...a, [q._id]: idx }))}
                      className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-left text-sm transition ${tone}`}
                    >
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full border text-xs font-bold">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      {opt}
                      {review && idx === review.correctIndex && <CheckCircle2 size={16} className="ml-auto text-emerald-500" />}
                      {review && chosen && idx !== review.correctIndex && <XCircle size={16} className="ml-auto text-rose-500" />}
                    </button>
                  );
                })}
              </div>

              {review?.explanation && (
                <p className="ml-10 mt-4 rounded-xl bg-zinc-50 px-4 py-3 text-sm text-zinc-600 dark:bg-ink-700 dark:text-zinc-300">
                  {review.explanation}
                </p>
              )}
            </div>
          );
        })}

        {questions && !result && (
          <button className="btn-primary mt-8 w-full py-3.5" onClick={submit} disabled={busy || !Object.keys(answers).length}>
            {busy ? "Scoring..." : `Submit ${Object.keys(answers).length} of ${questions.length} answers`}
          </button>
        )}
      </div>
    </DashboardLayout>
  );
}
