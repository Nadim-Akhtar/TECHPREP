import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="grid min-h-screen place-items-center px-5 text-center">
      <div>
        <p className="text-6xl font-extrabold tracking-tight">404</p>
        <p className="mt-3 text-zinc-600 dark:text-zinc-400">That page is not part of the syllabus.</p>
        <Link to="/" className="btn-primary mt-8">Back to home</Link>
      </div>
    </div>
  );
}
