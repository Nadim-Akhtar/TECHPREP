import { useState } from "react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function Profile() {
  const { user, updateProfile } = useAuth();
  const [form, setForm] = useState({
    name: user?.name || "",
    college: user?.college || "",
    gradYear: user?.gradYear || "",
    targetRole: user?.targetRole || "SDE",
    dailyGoalMinutes: user?.dailyGoalMinutes || 45,
  });
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    setStatus("");
    try {
      await updateProfile({
        ...form,
        gradYear: form.gradYear ? Number(form.gradYear) : null,
        dailyGoalMinutes: Number(form.dailyGoalMinutes),
      });
      setStatus("Profile saved.");
    } catch (err) {
      setStatus(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-xl animate-rise">
        <h1 className="text-4xl font-extrabold tracking-tight">Your profile</h1>
        <p className="mt-2 text-zinc-600 dark:text-zinc-400">This shapes your dashboard goals and greeting.</p>

        <form onSubmit={save} className="card mt-8 space-y-5 p-7">
          <div>
            <label className="mb-1.5 block text-sm font-medium">Name</label>
            <input className="field" value={form.name} onChange={set("name")} required />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium">Email</label>
            <input className="field cursor-not-allowed opacity-60" value={user?.email} readOnly />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-medium">College</label>
              <input className="field" value={form.college} onChange={set("college")} />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium">Graduation year</label>
              <input type="number" className="field" value={form.gradYear} onChange={set("gradYear")} />
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-medium">Target role</label>
              <input className="field" value={form.targetRole} onChange={set("targetRole")} />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium">Daily goal (minutes)</label>
              <input type="number" min="10" max="600" className="field" value={form.dailyGoalMinutes} onChange={set("dailyGoalMinutes")} />
            </div>
          </div>

          {status && <p className="text-sm text-zinc-600 dark:text-zinc-400">{status}</p>}
          <button className="btn-primary w-full py-3" disabled={busy}>{busy ? "Saving..." : "Save changes"}</button>
        </form>
      </div>
    </DashboardLayout>
  );
}
