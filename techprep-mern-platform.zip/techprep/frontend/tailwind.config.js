/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["'Plus Jakarta Sans'", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      colors: {
        brand: {
          50: "#f3f1ff",
          100: "#e9e5ff",
          200: "#d5cdff",
          300: "#b7a6ff",
          400: "#9575ff",
          500: "#7c4dff",
          600: "#6d34f5",
          700: "#5c24d8",
          800: "#4c1fae",
          900: "#3f1d8b",
        },
        ink: {
          900: "#0d0d12",
          800: "#15151c",
          700: "#1d1d26",
          600: "#2a2a35",
        },
        ember: "#ff7a1a",
      },
      boxShadow: {
        lift: "0 18px 40px -22px rgba(76, 31, 174, 0.45)",
        panel: "0 1px 2px rgba(16,16,24,.04), 0 8px 24px -16px rgba(16,16,24,.25)",
      },
      keyframes: {
        rise: { "0%": { opacity: 0, transform: "translateY(14px)" }, "100%": { opacity: 1, transform: "none" } },
      },
      animation: { rise: "rise .5s cubic-bezier(.2,.7,.3,1) both" },
    },
  },
  plugins: [],
};
