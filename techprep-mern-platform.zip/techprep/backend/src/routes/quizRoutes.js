import express from "express";
import { getQuestions, getTopics, submitQuiz, getAttempts } from "../controllers/quizController.js";
import { protect } from "../middleware/auth.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = express.Router();

router.get("/", asyncHandler(getQuestions));
router.get("/topics", asyncHandler(getTopics));
router.get("/attempts", protect, asyncHandler(getAttempts));
router.post("/submit", protect, asyncHandler(submitQuiz));

export default router;
