import express from "express";
import {
  toggleSolved,
  toggleRevision,
  saveNote,
  getSummary,
  logLearningTime,
} from "../controllers/progressController.js";
import { protect } from "../middleware/auth.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = express.Router();
router.use(protect);

router.get("/summary", asyncHandler(getSummary));
router.post("/learning-time", asyncHandler(logLearningTime));
router.patch("/:problemId/solve", asyncHandler(toggleSolved));
router.patch("/:problemId/revision", asyncHandler(toggleRevision));
router.put("/:problemId/note", asyncHandler(saveNote));

export default router;
