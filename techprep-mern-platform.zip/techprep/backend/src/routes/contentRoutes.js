import express from "express";
import { getInterviewQuestions, getCompanies, getCompanyBySlug } from "../controllers/contentController.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = express.Router();

router.get("/interview", asyncHandler(getInterviewQuestions));
router.get("/companies", asyncHandler(getCompanies));
router.get("/companies/:slug", asyncHandler(getCompanyBySlug));

export default router;
