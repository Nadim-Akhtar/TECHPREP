import express from "express";
import {
  getProblems,
  getRoadmap,
  getProblemBySlug,
  getRandomProblem,
  createProblem,
} from "../controllers/problemController.js";
import { protect, adminOnly } from "../middleware/auth.js";
import { optionalAuth } from "../middleware/optionalAuth.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = express.Router();

router.get("/", optionalAuth, asyncHandler(getProblems));
router.get("/roadmap", optionalAuth, asyncHandler(getRoadmap));
router.get("/random", asyncHandler(getRandomProblem));
router.get("/:slug", asyncHandler(getProblemBySlug));
router.post("/", protect, adminOnly, asyncHandler(createProblem));

export default router;
