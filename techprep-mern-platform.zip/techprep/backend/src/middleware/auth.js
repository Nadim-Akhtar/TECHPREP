import jwt from "jsonwebtoken";
import User from "../models/User.js";

export const protect = async (req, res, next) => {
  let token;
  const header = req.headers.authorization;

  if (header && header.startsWith("Bearer ")) token = header.split(" ")[1];
  else if (req.cookies?.token) token = req.cookies.token;

  if (!token) {
    return res.status(401).json({ message: "Sign in to continue." });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select("-password");
    if (!user) return res.status(401).json({ message: "This account no longer exists." });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ message: "Session expired. Sign in again." });
  }
};

export const adminOnly = (req, res, next) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ message: "Admin access required." });
  }
  next();
};
