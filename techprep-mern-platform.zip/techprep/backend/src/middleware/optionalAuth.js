import jwt from "jsonwebtoken";
import User from "../models/User.js";

// Attaches req.user when a valid token exists, but never blocks the request.
export const optionalAuth = async (req, res, next) => {
  const header = req.headers.authorization;
  const token = header?.startsWith("Bearer ") ? header.split(" ")[1] : req.cookies?.token;
  if (!token) return next();
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id).select("-password");
  } catch {
    /* ignore invalid token in public routes */
  }
  next();
};
