export const notFound = (req, res, next) => {
  res.status(404);
  next(new Error(`Route not found: ${req.originalUrl}`));
};

export const errorHandler = (err, req, res, next) => { // eslint-disable-line
  let status = res.statusCode && res.statusCode !== 200 ? res.statusCode : 500;
  let message = err.message || "Something went wrong.";

  if (err.name === "CastError" && err.kind === "ObjectId") {
    status = 404;
    message = "Resource not found.";
  }
  if (err.code === 11000) {
    status = 400;
    message = `${Object.keys(err.keyPattern).join(", ")} already in use.`;
  }
  if (err.name === "ValidationError") {
    status = 400;
    message = Object.values(err.errors).map((e) => e.message).join(", ");
  }

  res.status(status).json({
    message,
    stack: process.env.NODE_ENV === "production" ? undefined : err.stack,
  });
};
