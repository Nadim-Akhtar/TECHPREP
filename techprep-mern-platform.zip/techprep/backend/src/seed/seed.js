import dotenv from "dotenv";
dotenv.config();

import mongoose from "mongoose";
import { connectDB } from "../config/db.js";

import User from "../models/User.js";
import Problem from "../models/Problem.js";
import Question from "../models/Question.js";
import InterviewQuestion from "../models/InterviewQuestion.js";
import Company from "../models/Company.js";
import Progress from "../models/Progress.js";
import Attempt from "../models/Attempt.js";

import { dsaProblems } from "./data/dsa.js";
import { developmentTopics, coreCSTopics, systemDesignTopics, interviewTopics } from "./data/tracks.js";
import { allQuestions } from "./data/questions.js";
import { interviewQuestions, companies } from "./data/interview.js";

const run = async () => {
  await connectDB();
  const destroy = process.argv.includes("--destroy");

  await Promise.all([
    Problem.deleteMany({}),
    Question.deleteMany({}),
    InterviewQuestion.deleteMany({}),
    Company.deleteMany({}),
    Progress.deleteMany({}),
    Attempt.deleteMany({}),
  ]);

  if (destroy) {
    await User.deleteMany({});
    console.log("All collections cleared.");
    await mongoose.connection.close();
    return;
  }

  const problems = [
    ...dsaProblems,
    ...developmentTopics,
    ...coreCSTopics,
    ...systemDesignTopics,
    ...interviewTopics,
  ];

  await Problem.insertMany(problems);
  await Question.insertMany(allQuestions);
  await InterviewQuestion.insertMany(interviewQuestions);
  await Company.insertMany(companies);

  const demoEmail = "nadim@techprep.dev";
  let demo = await User.findOne({ email: demoEmail });
  if (!demo) {
    demo = await User.create({
      name: "Nadim",
      email: demoEmail,
      password: "test1234",
      college: "TechPrep Institute of Technology",
      gradYear: 2027,
      dailyGoalMinutes: 45,
      minutesLearned: 750,
      streak: { count: 7, lastActiveOn: new Date() },
    });
  }

  console.log(`Seeded ${problems.length} topics, ${allQuestions.length} quiz questions, ${interviewQuestions.length} interview answers, ${companies.length} companies.`);
  console.log(`Demo login -> ${demoEmail} / test1234`);
  await mongoose.connection.close();
};

run().catch(async (err) => {
  console.error(err);
  await mongoose.connection.close();
  process.exit(1);
});
