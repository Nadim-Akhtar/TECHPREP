const q = (track, topic, question, options, correctIndex, explanation, difficulty = "Easy") => ({
  track, topic, question, options, correctIndex, explanation, difficulty,
});

export const aptitudeQuestions = [
  q("aptitude", "Percentages", "A number is increased by 20% and then decreased by 20%. What is the net change?", ["No change", "4% increase", "4% decrease", "2% decrease"], 2, "Net change = +20 - 20 - (20x20)/100 = -4%, so a 4% decrease.", "Easy"),
  q("aptitude", "Percentages", "If 40% of a number is 96, the number is:", ["240", "220", "260", "180"], 0, "Number = 96 x 100 / 40 = 240.", "Easy"),
  q("aptitude", "Percentages", "The price of rice rises by 25%. By what percent must consumption fall to keep spending the same?", ["25%", "20%", "15%", "30%"], 1, "Reduction = 25/(100+25) x 100 = 20%.", "Medium"),
  q("aptitude", "Profit and Loss", "An article bought for 400 is sold for 500. Find the profit percent.", ["20%", "25%", "30%", "15%"], 1, "Profit = 100 on cost 400, so 100/400 x 100 = 25%.", "Easy"),
  q("aptitude", "Profit and Loss", "A shopkeeper marks goods 40% above cost and gives a 10% discount. Profit percent is:", ["26%", "30%", "24%", "28%"], 0, "SP = 1.4 x 0.9 = 1.26 times cost, so profit is 26%.", "Medium"),
  q("aptitude", "Time and Work", "A does a job in 10 days, B in 15 days. Together they finish it in:", ["5 days", "6 days", "7 days", "8 days"], 1, "Combined rate = 1/10 + 1/15 = 1/6, so 6 days.", "Easy"),
  q("aptitude", "Time and Work", "12 men finish work in 18 days. How many days will 27 men take?", ["8", "9", "6", "12"], 0, "Men x days is constant: 12x18 = 27xd, so d = 8.", "Medium"),
  q("aptitude", "Time Speed Distance", "A train 120 m long runs at 54 km/h. Time to cross a pole is:", ["6 s", "8 s", "10 s", "12 s"], 1, "54 km/h = 15 m/s, so time = 120/15 = 8 seconds.", "Easy"),
  q("aptitude", "Time Speed Distance", "Two trains 100 m and 150 m long move towards each other at 36 km/h and 54 km/h. Crossing time:", ["10 s", "12 s", "9 s", "15 s"], 0, "Relative speed = 90 km/h = 25 m/s, total length 250 m, time = 10 s.", "Medium"),
  q("aptitude", "Averages", "The average of 5 numbers is 27. If one number is removed the average becomes 25. The removed number is:", ["35", "30", "40", "25"], 0, "Sum was 135, new sum is 100, so removed = 35.", "Medium"),
  q("aptitude", "Ratio and Proportion", "If a:b = 3:4 and b:c = 8:9, then a:c is:", ["2:3", "3:4", "1:2", "4:9"], 0, "a:b:c = 6:8:9, so a:c = 6:9 = 2:3.", "Medium"),
  q("aptitude", "Simple and Compound Interest", "SI on 5000 for 2 years at 10% per annum is:", ["1000", "1100", "900", "1200"], 0, "SI = 5000 x 10 x 2 / 100 = 1000.", "Easy"),
  q("aptitude", "Simple and Compound Interest", "CI on 10000 for 2 years at 10% per annum is:", ["2000", "2100", "2200", "1900"], 1, "Amount = 10000 x 1.1 x 1.1 = 12100, so CI = 2100.", "Medium"),
  q("aptitude", "Permutation and Combination", "In how many ways can the letters of DELHI be arranged?", ["60", "120", "24", "720"], 1, "5 distinct letters give 5! = 120 arrangements.", "Easy"),
  q("aptitude", "Probability", "Probability of getting a sum of 7 with two dice is:", ["1/6", "1/9", "5/36", "1/12"], 0, "6 favourable outcomes out of 36, which is 1/6.", "Medium"),
  q("aptitude", "Numbers", "The HCF of 24 and 36 is:", ["6", "12", "8", "18"], 1, "24 = 2^3x3 and 36 = 2^2x3^2, so HCF = 2^2x3 = 12.", "Easy"),
  q("aptitude", "Numbers", "The LCM of 12 and 18 is:", ["36", "48", "72", "24"], 0, "LCM = 2^2 x 3^2 = 36.", "Easy"),
  q("aptitude", "Mixtures", "In 40 litres of a 20% milk mixture, how much milk must be added to make it 50% milk?", ["24 L", "20 L", "18 L", "30 L"], 0, "Milk = 8 L, water = 32 L. For 50% milk, milk must equal water: add 24 L.", "Hard"),
  q("aptitude", "Ages", "A father is thrice as old as his son. After 10 years he will be twice as old. Son's present age is:", ["10", "12", "15", "8"], 0, "3s + 10 = 2(s + 10), so s = 10.", "Medium"),
  q("aptitude", "Pipes and Cisterns", "Pipe A fills a tank in 6 h, pipe B in 12 h. Together they fill it in:", ["3 h", "4 h", "5 h", "2 h"], 1, "Rate = 1/6 + 1/12 = 1/4, so 4 hours.", "Easy"),
];

export const reasoningQuestions = [
  q("reasoning", "Series", "Find the next term: 2, 6, 12, 20, 30, ?", ["40", "42", "44", "38"], 1, "Differences are 4, 6, 8, 10, so next difference is 12 and the term is 42.", "Easy"),
  q("reasoning", "Series", "Find the missing term: 3, 9, 27, 81, ?", ["162", "243", "216", "324"], 1, "Each term is multiplied by 3, so the next is 243.", "Easy"),
  q("reasoning", "Coding-Decoding", "If CAT is coded as DBU, then DOG is coded as:", ["EPH", "EPG", "DPH", "FQI"], 0, "Each letter shifts one step forward, giving EPH.", "Easy"),
  q("reasoning", "Blood Relations", "Pointing to a man, a woman said, 'His mother is the only daughter of my mother.' How is the woman related to him?", ["Sister", "Mother", "Aunt", "Grandmother"], 1, "The only daughter of her mother is the woman herself, so she is his mother.", "Medium"),
  q("reasoning", "Direction Sense", "A man walks 5 km north, turns right and walks 3 km, then turns right and walks 5 km. How far is he from the start?", ["3 km", "5 km", "8 km", "13 km"], 0, "He ends 3 km east of the starting point.", "Medium"),
  q("reasoning", "Syllogism", "All pens are books. All books are tables. Conclusion: All pens are tables.", ["Follows", "Does not follow", "Cannot be determined", "Partially follows"], 0, "The two universal statements chain together, so the conclusion follows.", "Easy"),
  q("reasoning", "Seating Arrangement", "Five friends sit in a row: D is at the left end, E at the right end, A sits right of D, and C sits right of B. Who sits in the middle?", ["A", "B", "C", "D"], 1, "The only valid order is D, A, B, C, E, so B takes the middle seat.", "Medium"),
  q("reasoning", "Clocks", "The angle between the hands of a clock at 3:30 is:", ["75 degrees", "90 degrees", "80 degrees", "65 degrees"], 0, "Hour hand is at 105 degrees, minute hand at 180 degrees, so the angle is 75 degrees.", "Medium"),
  q("reasoning", "Calendars", "If 1 January 2024 is a Monday, what day is 1 March 2024?", ["Thursday", "Friday", "Saturday", "Wednesday"], 1, "2024 is a leap year: 60 days later, 60 mod 7 = 4, so Monday + 4 = Friday.", "Hard"),
  q("reasoning", "Analogy", "Doctor is to Hospital as Teacher is to:", ["Student", "School", "Book", "Class"], 1, "A doctor works in a hospital, a teacher works in a school.", "Easy"),
  q("reasoning", "Odd One Out", "Find the odd one: Square, Rectangle, Circle, Triangle", ["Square", "Rectangle", "Circle", "Triangle"], 2, "A circle has no straight sides or vertices.", "Easy"),
  q("reasoning", "Statement and Assumption", "Statement: 'Use TechPrep to crack placements.' Assumption: People want to crack placements.", ["Implicit", "Not implicit", "Either", "Neither"], 0, "The advice only makes sense if the audience wants that outcome, so the assumption is implicit.", "Medium"),
];

export const coreCSQuestions = [
  q("corecs", "Operating Systems", "Which scheduling algorithm can cause starvation?", ["Round Robin", "First Come First Serve", "Priority Scheduling", "Shortest Remaining Time Next"], 2, "Low priority processes may never get the CPU under priority scheduling.", "Medium"),
  q("corecs", "Operating Systems", "Thrashing happens when:", ["CPU is idle", "Too much time is spent on page swapping", "Disk fails", "Too many threads are created"], 1, "Excessive paging leaves little time for useful work.", "Medium"),
  q("corecs", "Operating Systems", "Which is NOT a necessary condition for deadlock?", ["Mutual exclusion", "Hold and wait", "Preemption", "Circular wait"], 2, "Deadlock needs no-preemption, not preemption.", "Medium"),
  q("corecs", "DBMS", "Which normal form removes partial dependency?", ["1NF", "2NF", "3NF", "BCNF"], 1, "2NF removes partial dependency on a composite key.", "Medium"),
  q("corecs", "DBMS", "ACID stands for:", ["Atomicity, Consistency, Isolation, Durability", "Accuracy, Consistency, Integrity, Durability", "Atomicity, Concurrency, Isolation, Delivery", "Access, Control, Index, Data"], 0, "These are the four guarantees of a database transaction.", "Easy"),
  q("corecs", "DBMS", "A DELETE without WHERE removes:", ["The table", "All rows but keeps the table", "Nothing", "Only the first row"], 1, "DELETE removes rows, the table structure stays.", "Easy"),
  q("corecs", "Computer Networks", "Which protocol guarantees ordered, reliable delivery?", ["UDP", "TCP", "ICMP", "ARP"], 1, "TCP is connection oriented with acknowledgements and retransmission.", "Easy"),
  q("corecs", "Computer Networks", "DNS mainly runs on which port?", ["21", "53", "80", "443"], 1, "DNS uses port 53.", "Easy"),
  q("corecs", "Computer Networks", "Which layer does a router work on?", ["Data link", "Network", "Transport", "Application"], 1, "Routers forward packets using network layer IP addresses.", "Easy"),
  q("corecs", "OOPs", "Runtime polymorphism in C++ is achieved through:", ["Function overloading", "Virtual functions", "Templates", "Operator overloading"], 1, "Virtual functions resolve the call at runtime through the vtable.", "Medium"),
  q("corecs", "OOPs", "Which SOLID letter stands for dependency inversion?", ["S", "O", "I", "D"], 3, "D is the dependency inversion principle.", "Easy"),
  q("corecs", "OOPs", "Abstraction is best described as:", ["Hiding implementation and showing behaviour", "Combining data and methods", "Reusing parent class code", "Creating many object copies"], 0, "Abstraction exposes what an object does, not how it does it.", "Easy"),
];

export const allQuestions = [...aptitudeQuestions, ...reasoningQuestions, ...coreCSQuestions];
