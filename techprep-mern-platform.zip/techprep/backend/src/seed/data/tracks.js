const slugify = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

const build = (track, rows) =>
  rows.map(([section, topic, title, difficulty, tags], i) => ({
    track,
    section,
    topic,
    title,
    slug: `${track}-${slugify(title)}`,
    difficulty,
    tags,
    articleUrl: `https://developer.mozilla.org/en-US/search?q=${encodeURIComponent(title)}`,
    videoUrl: `https://www.youtube.com/results?search_query=${encodeURIComponent(title)}`,
    order: i + 1,
  }));

export const developmentTopics = build("development", [
  ["Frontend Foundations", "HTML & CSS", "Semantic HTML and Accessibility", "Easy", ["html"]],
  ["Frontend Foundations", "HTML & CSS", "Flexbox Layout", "Easy", ["css"]],
  ["Frontend Foundations", "HTML & CSS", "CSS Grid Layout", "Easy", ["css"]],
  ["Frontend Foundations", "HTML & CSS", "Responsive Design and Media Queries", "Easy", ["css"]],
  ["Frontend Foundations", "JavaScript", "let, const and Scope", "Easy", ["javascript"]],
  ["Frontend Foundations", "JavaScript", "Closures and Hoisting", "Medium", ["javascript"]],
  ["Frontend Foundations", "JavaScript", "Promises and async/await", "Medium", ["javascript"]],
  ["Frontend Foundations", "JavaScript", "Event Loop and Microtasks", "Hard", ["javascript"]],
  ["Frontend Foundations", "JavaScript", "Array Methods: map, filter, reduce", "Easy", ["javascript"]],
  ["Frontend Foundations", "JavaScript", "Debounce and Throttle", "Medium", ["javascript"]],

  ["React", "React Core", "JSX and Components", "Easy", ["react"]],
  ["React", "React Core", "Props and State", "Easy", ["react"]],
  ["React", "React Core", "useEffect and the Dependency Array", "Medium", ["react"]],
  ["React", "React Core", "Lifting State and Context API", "Medium", ["react"]],
  ["React", "React Core", "Custom Hooks", "Medium", ["react"]],
  ["React", "React Core", "React Router and Protected Routes", "Medium", ["react"]],
  ["React", "React Performance", "Memoisation with useMemo and useCallback", "Medium", ["react"]],
  ["React", "React Performance", "Code Splitting and Lazy Loading", "Hard", ["react"]],

  ["Backend", "Node & Express", "Node.js Runtime and Modules", "Easy", ["node"]],
  ["Backend", "Node & Express", "Express Routing and Middleware", "Easy", ["express"]],
  ["Backend", "Node & Express", "REST API Design", "Medium", ["api"]],
  ["Backend", "Node & Express", "Error Handling Middleware", "Medium", ["express"]],
  ["Backend", "Auth & Security", "JWT Authentication Flow", "Medium", ["auth"]],
  ["Backend", "Auth & Security", "Password Hashing with bcrypt", "Easy", ["auth"]],
  ["Backend", "Auth & Security", "CORS, Helmet and Rate Limiting", "Medium", ["security"]],
  ["Backend", "Databases", "MongoDB Documents and Collections", "Easy", ["mongodb"]],
  ["Backend", "Databases", "Mongoose Schemas and Validation", "Medium", ["mongodb"]],
  ["Backend", "Databases", "Aggregation Pipeline", "Hard", ["mongodb"]],
  ["Backend", "Databases", "Indexing and Query Performance", "Hard", ["mongodb"]],

  ["Ship It", "Projects", "Build a Full Stack CRUD App", "Medium", ["project"]],
  ["Ship It", "Projects", "Add File Uploads with Multer and Cloud Storage", "Medium", ["project"]],
  ["Ship It", "Projects", "Deploy Frontend on Vercel and API on Render", "Medium", ["deployment"]],
  ["Ship It", "Projects", "Write a README That Gets You Shortlisted", "Easy", ["career"]],
  ["Ship It", "Git", "Git Branching and Pull Requests", "Easy", ["git"]],
]);

export const coreCSTopics = build("corecs", [
  ["Operating Systems", "Process Management", "Process vs Thread", "Easy", ["os"]],
  ["Operating Systems", "Process Management", "CPU Scheduling Algorithms", "Medium", ["os"]],
  ["Operating Systems", "Process Management", "Context Switching", "Easy", ["os"]],
  ["Operating Systems", "Synchronisation", "Deadlock: Conditions and Prevention", "Medium", ["os"]],
  ["Operating Systems", "Synchronisation", "Semaphores and Mutex", "Medium", ["os"]],
  ["Operating Systems", "Memory", "Paging and Segmentation", "Medium", ["os"]],
  ["Operating Systems", "Memory", "Virtual Memory and Page Replacement", "Hard", ["os"]],

  ["DBMS", "Design", "ER Model and Keys", "Easy", ["dbms"]],
  ["DBMS", "Design", "Normalisation: 1NF to BCNF", "Medium", ["dbms"]],
  ["DBMS", "SQL", "Joins: Inner, Left, Right, Full", "Easy", ["sql"]],
  ["DBMS", "SQL", "Group By, Having and Window Functions", "Medium", ["sql"]],
  ["DBMS", "Transactions", "ACID Properties", "Easy", ["dbms"]],
  ["DBMS", "Transactions", "Isolation Levels and Locking", "Hard", ["dbms"]],
  ["DBMS", "Performance", "Indexing: B-Tree and Hash", "Medium", ["dbms"]],

  ["Computer Networks", "Models", "OSI vs TCP/IP Model", "Easy", ["cn"]],
  ["Computer Networks", "Transport", "TCP vs UDP", "Easy", ["cn"]],
  ["Computer Networks", "Transport", "Three-Way Handshake", "Medium", ["cn"]],
  ["Computer Networks", "Application", "HTTP, HTTPS and TLS", "Medium", ["cn"]],
  ["Computer Networks", "Application", "DNS Resolution Flow", "Medium", ["cn"]],
  ["Computer Networks", "Application", "What Happens When You Type a URL", "Medium", ["cn"]],

  ["OOPs", "Pillars", "Encapsulation and Abstraction", "Easy", ["oops"]],
  ["OOPs", "Pillars", "Inheritance and Types", "Easy", ["oops"]],
  ["OOPs", "Pillars", "Polymorphism: Compile Time vs Runtime", "Medium", ["oops"]],
  ["OOPs", "Design", "SOLID Principles", "Medium", ["oops"]],
  ["OOPs", "Design", "Singleton, Factory and Observer Patterns", "Medium", ["design-patterns"]],
]);

export const systemDesignTopics = build("system-design", [
  ["Low Level Design", "Foundations", "Class Diagrams and UML Basics", "Easy", ["lld"]],
  ["Low Level Design", "Foundations", "SOLID in Practice", "Medium", ["lld"]],
  ["Low Level Design", "Case Studies", "Design a Parking Lot", "Medium", ["lld"]],
  ["Low Level Design", "Case Studies", "Design a Splitwise Clone", "Medium", ["lld"]],
  ["Low Level Design", "Case Studies", "Design an Elevator System", "Hard", ["lld"]],
  ["High Level Design", "Building Blocks", "Load Balancing Strategies", "Medium", ["hld"]],
  ["High Level Design", "Building Blocks", "Caching and Cache Invalidation", "Medium", ["hld"]],
  ["High Level Design", "Building Blocks", "Database Sharding and Replication", "Hard", ["hld"]],
  ["High Level Design", "Building Blocks", "CAP Theorem", "Medium", ["hld"]],
  ["High Level Design", "Building Blocks", "Message Queues and Async Processing", "Medium", ["hld"]],
  ["High Level Design", "Case Studies", "Design a URL Shortener", "Medium", ["hld"]],
  ["High Level Design", "Case Studies", "Design a Rate Limiter", "Medium", ["hld"]],
  ["High Level Design", "Case Studies", "Design a News Feed", "Hard", ["hld"]],
  ["High Level Design", "Case Studies", "Design WhatsApp Chat", "Hard", ["hld"]],
]);

export const interviewTopics = build("interview", [
  ["Resume & Profile", "Resume", "One-Page Resume Structure for Freshers", "Easy", ["resume"]],
  ["Resume & Profile", "Resume", "Writing Impact Bullets with Numbers", "Easy", ["resume"]],
  ["Resume & Profile", "Profile", "LinkedIn and GitHub Cleanup", "Easy", ["profile"]],
  ["Rounds", "Online Assessment", "Solving OA Under Time Pressure", "Medium", ["oa"]],
  ["Rounds", "Technical Round", "Explaining Your Approach Out Loud", "Medium", ["technical"]],
  ["Rounds", "Technical Round", "Dry Running Code on a Whiteboard", "Medium", ["technical"]],
  ["Rounds", "HR Round", "Tell Me About Yourself", "Easy", ["hr"]],
  ["Rounds", "HR Round", "Strengths, Weaknesses and Salary Questions", "Easy", ["hr"]],
  ["Rounds", "Behavioural", "STAR Method for Behavioural Answers", "Medium", ["behavioural"]],
  ["Rounds", "Behavioural", "Handling Conflict and Failure Questions", "Medium", ["behavioural"]],
  ["Mock Practice", "Mock", "Weekly Mock Interview Routine", "Easy", ["mock"]],
  ["Mock Practice", "Mock", "Questions to Ask the Interviewer", "Easy", ["hr"]],
]);
