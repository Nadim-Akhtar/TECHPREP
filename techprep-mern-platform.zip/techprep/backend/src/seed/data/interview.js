export const interviewQuestions = [
  {
    category: "HR",
    question: "Tell me about yourself.",
    answer:
      "Give a 60 to 90 second arc: who you are today (branch, year, college), one or two things you have built or solved that prove your skills, and why this role is the next step. Keep it forward looking and end on the company.",
    tips: ["Rehearse aloud, do not memorise word for word", "Mention one project with a concrete number", "Close by connecting to the job description"],
    companies: ["TCS", "Infosys", "Wipro", "Amazon"],
  },
  {
    category: "HR",
    question: "What is your biggest weakness?",
    answer:
      "Name a real, non-critical weakness and show the system you built to manage it. For example: you used to over-engineer early versions, so now you ship a working slice first and refactor after review.",
    tips: ["Avoid the fake weakness trap such as 'I work too hard'", "Show progress, not just awareness"],
    companies: ["Infosys", "Capgemini"],
  },
  {
    category: "HR",
    question: "Why should we hire you?",
    answer:
      "Map two or three requirements from the job description to specific evidence from your work, then add what you bring beyond the checklist, such as shipping speed or ownership.",
    tips: ["Quote the job description back", "One sentence per requirement"],
    companies: ["Accenture", "Cognizant"],
  },
  {
    category: "HR",
    question: "Where do you see yourself in five years?",
    answer:
      "Describe growth in depth rather than titles: becoming the person the team trusts on a system, then mentoring juniors. Tie it to the company's own career track.",
    tips: ["Avoid saying you want to start your own company", "Show you plan to stay and grow"],
    companies: ["TCS", "Wipro"],
  },
  {
    category: "Behavioural",
    question: "Tell me about a time you failed.",
    answer:
      "Use STAR. Pick a real failure with a clear cost, own your part without blaming teammates, and spend most of the answer on what changed in how you work afterwards.",
    tips: ["Situation and Task short, Action and Result long", "End with the lesson applied to a later project"],
    companies: ["Amazon", "Microsoft"],
  },
  {
    category: "Behavioural",
    question: "Describe a conflict with a teammate and how you handled it.",
    answer:
      "Show that you separated the person from the problem: you surfaced the disagreement early, brought data or a prototype instead of opinion, and agreed on a decision rule.",
    tips: ["Never badmouth the teammate", "Show the outcome for the project, not who won"],
    companies: ["Amazon", "Flipkart"],
  },
  {
    category: "Behavioural",
    question: "Tell me about a time you worked under a tight deadline.",
    answer:
      "Explain how you cut scope rather than quality: what you shipped, what you deferred, and how you communicated the tradeoff to the team.",
    tips: ["Name the tradeoff explicitly", "Include the result with a number"],
    companies: ["Zoho", "Paytm"],
  },
  {
    category: "Technical",
    question: "What is the difference between an array and a linked list?",
    answer:
      "Arrays store elements contiguously, so indexing is O(1) but insertion in the middle is O(n) and resizing costs a copy. Linked lists store nodes with pointers, so insertion and deletion at a known node are O(1) but access is O(n) and cache locality is poor.",
    tips: ["Mention cache locality, most candidates miss it", "Give one use case for each"],
    companies: ["Amazon", "Microsoft", "Adobe"],
  },
  {
    category: "Technical",
    question: "Explain the difference between SQL and NoSQL databases.",
    answer:
      "SQL databases use fixed schemas, relations and strong ACID transactions, which suits financial and highly relational data. NoSQL stores such as MongoDB are schema flexible and scale horizontally, which suits evolving documents and heavy read workloads with denormalised data.",
    tips: ["Pick a side for a given use case, do not sit on the fence", "Mention joins vs embedding"],
    companies: ["Flipkart", "Swiggy"],
  },
  {
    category: "Technical",
    question: "What happens when you type a URL in the browser and press Enter?",
    answer:
      "Browser checks its cache, resolves DNS to an IP, opens a TCP connection and completes the TLS handshake for HTTPS, sends an HTTP request, the server responds, and the browser parses HTML, builds the DOM and CSSOM, runs JavaScript, and paints the page.",
    tips: ["Go layer by layer", "Stop and ask how deep they want you to go"],
    companies: ["Google", "Amazon", "Uber"],
  },
  {
    category: "Technical",
    question: "How does JWT authentication work?",
    answer:
      "On login the server verifies credentials and signs a token containing the user id and expiry. The client sends it on each request in the Authorization header. The server verifies the signature statelessly, so no session store is needed, but tokens cannot be revoked easily before expiry.",
    tips: ["Mention short access tokens plus refresh tokens", "Never store secrets in the payload"],
    companies: ["Paytm", "Razorpay"],
  },
  {
    category: "Technical",
    question: "What is the difference between process and thread?",
    answer:
      "A process has its own address space and resources, while threads within a process share memory and file descriptors. Threads are cheaper to create and switch between, but sharing memory brings race conditions that need synchronisation.",
    tips: ["Mention context switch cost", "Bring up a real example such as a browser tab"],
    companies: ["Microsoft", "Oracle"],
  },
  {
    category: "Technical",
    question: "Explain time complexity of quicksort and when it degrades.",
    answer:
      "Average case is O(n log n) because partitions split the array roughly in half. Worst case is O(n squared) when the pivot is always the smallest or largest element, for example an already sorted array with a first-element pivot. Randomised or median-of-three pivots avoid this.",
    tips: ["Mention in-place and unstable nature", "Compare with mergesort"],
    companies: ["Amazon", "Goldman Sachs"],
  },
  {
    category: "System Design",
    question: "Design a URL shortener.",
    answer:
      "Core pieces are an id generator (base62 of an auto-increment or a hash with collision check), a key-value store mapping short code to long URL, a cache for hot links, and a redirect service returning 301 or 302. Discuss read-heavy traffic, custom aliases, expiry and analytics.",
    tips: ["State the read to write ratio early", "Do capacity estimation before design"],
    companies: ["Amazon", "Uber"],
  },
  {
    category: "System Design",
    question: "How would you design a rate limiter?",
    answer:
      "Compare fixed window, sliding window log and token bucket. Token bucket in Redis with atomic Lua scripts handles bursts well. Key by user id or API key, keep counters in memory close to the edge, and return 429 with a Retry-After header.",
    tips: ["Mention distributed counters and clock skew", "Discuss what happens when Redis is down"],
    companies: ["Google", "Cloudflare"],
  },
];

export const companies = [
  {
    name: "Amazon",
    slug: "amazon",
    logoText: "AMZ",
    role: "SDE-1",
    ctc: "INR 20-44 LPA",
    difficulty: "Hard",
    rounds: [
      { name: "Online Assessment", detail: "Two DSA problems plus work-style and debugging sections" },
      { name: "Technical 1", detail: "Data structures, one medium and one hard problem" },
      { name: "Technical 2", detail: "Problem solving plus low level design" },
      { name: "Bar Raiser", detail: "Leadership principles with deep behavioural probing" },
    ],
    focusAreas: ["Arrays", "Trees", "Graphs", "DP", "Leadership Principles"],
    topProblems: ["Two Sum", "Number of Islands", "Trapping Rain Water", "LRU Cache", "Merge Intervals"],
  },
  {
    name: "Microsoft",
    slug: "microsoft",
    logoText: "MS",
    role: "SDE",
    ctc: "INR 18-45 LPA",
    difficulty: "Hard",
    rounds: [
      { name: "Online Assessment", detail: "Two to three coding problems on Codility" },
      { name: "Technical 1", detail: "DSA with edge case discussion" },
      { name: "Technical 2", detail: "OS, DBMS and system fundamentals" },
      { name: "AA Round", detail: "As-appropriate round with a senior manager" },
    ],
    focusAreas: ["Linked List", "Trees", "Strings", "OS", "OOPs"],
    topProblems: ["Reverse Linked List", "Validate BST", "Sort Colors", "Rotate Matrix"],
  },
  {
    name: "Google",
    slug: "google",
    logoText: "G",
    role: "SWE",
    ctc: "INR 25-60 LPA",
    difficulty: "Hard",
    rounds: [
      { name: "Phone Screen", detail: "One medium to hard problem with live coding" },
      { name: "Onsite x3", detail: "Algorithms, data structures and complexity analysis" },
      { name: "Googleyness", detail: "Behavioural and collaboration signals" },
    ],
    focusAreas: ["Graphs", "DP", "Binary Search", "Complexity Analysis"],
    topProblems: ["Course Schedule", "Median of Two Sorted Arrays", "Edit Distance", "Word Ladder"],
  },
  {
    name: "TCS",
    slug: "tcs",
    logoText: "TCS",
    role: "Digital / Ninja",
    ctc: "INR 3.5-9 LPA",
    difficulty: "Easy",
    rounds: [
      { name: "NQT", detail: "Aptitude, reasoning, verbal and two coding problems" },
      { name: "Technical", detail: "Project, DBMS, OOPs and basic coding" },
      { name: "MR and HR", detail: "Managerial and HR fit" },
    ],
    focusAreas: ["Aptitude", "Reasoning", "C/C++ Basics", "DBMS", "Projects"],
    topProblems: ["Reverse a String", "Prime Numbers", "Pattern Printing", "Simple SQL Queries"],
  },
  {
    name: "Infosys",
    slug: "infosys",
    logoText: "INF",
    role: "System Engineer / SP",
    ctc: "INR 3.6-9.5 LPA",
    difficulty: "Easy",
    rounds: [
      { name: "Online Test", detail: "Logical reasoning, quants, verbal and pseudocode" },
      { name: "Technical", detail: "Core CS, project and basic coding" },
      { name: "HR", detail: "Relocation, communication and fit" },
    ],
    focusAreas: ["Pseudocode", "Aptitude", "DBMS", "OOPs"],
    topProblems: ["Array Rotation", "String Palindrome", "Basic Recursion"],
  },
  {
    name: "Flipkart",
    slug: "flipkart",
    logoText: "FK",
    role: "SDE-1",
    ctc: "INR 18-32 LPA",
    difficulty: "Hard",
    rounds: [
      { name: "Online Assessment", detail: "Two to three algorithmic problems" },
      { name: "Machine Coding", detail: "Build a working module in 90 minutes" },
      { name: "Problem Solving", detail: "DSA with optimisation discussion" },
      { name: "Hiring Manager", detail: "Design and culture fit" },
    ],
    focusAreas: ["Machine Coding", "LLD", "DP", "Graphs"],
    topProblems: ["Count Inversions", "0/1 Knapsack", "Design Splitwise", "Copy List with Random Pointer"],
  },
  {
    name: "Zoho",
    slug: "zoho",
    logoText: "ZH",
    role: "Member Technical Staff",
    ctc: "INR 6-12 LPA",
    difficulty: "Medium",
    rounds: [
      { name: "Aptitude", detail: "Quants and reasoning screening" },
      { name: "Programming 1", detail: "Basic to medium coding on paper or machine" },
      { name: "Advanced Programming", detail: "Build a small application end to end" },
      { name: "Technical and HR", detail: "Discussion on your code and fit" },
    ],
    focusAreas: ["Strings", "Arrays", "OOPs", "Application Building"],
    topProblems: ["Matrix Spiral", "String Manipulation", "Bank Account Simulation"],
  },
  {
    name: "Accenture",
    slug: "accenture",
    logoText: "ACN",
    role: "ASE",
    ctc: "INR 4.6-11 LPA",
    difficulty: "Easy",
    rounds: [
      { name: "Cognitive and Technical", detail: "Aptitude plus MS Office, networking and pseudocode" },
      { name: "Coding", detail: "Two problems in a supported language" },
      { name: "Communication and HR", detail: "Versant test and HR round" },
    ],
    focusAreas: ["Aptitude", "Pseudocode", "Networking Basics", "Communication"],
    topProblems: ["Sum of Digits", "Find Duplicates", "Simple Sorting"],
  },
];
