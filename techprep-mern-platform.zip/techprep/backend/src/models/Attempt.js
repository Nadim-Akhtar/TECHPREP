import mongoose from "mongoose";

const attemptSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    track: { type: String, required: true },
    topic: { type: String, default: "Mixed" },
    total: { type: Number, required: true },
    correct: { type: Number, required: true },
    timeTakenSec: { type: Number, default: 0 },
    answers: [{ question: { type: mongoose.Schema.Types.ObjectId, ref: "Question" }, chosen: Number, isCorrect: Boolean }],
  },
  { timestamps: true }
);

export default mongoose.model("Attempt", attemptSchema);
