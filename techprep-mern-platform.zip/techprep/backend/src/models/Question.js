import mongoose from "mongoose";

// Used by Aptitude, Reasoning and Core CS quizzes
const questionSchema = new mongoose.Schema(
  {
    track: { type: String, required: true, index: true }, // aptitude | reasoning | corecs
    topic: { type: String, required: true },              // Percentages, Syllogism, OS ...
    question: { type: String, required: true },
    options: {
      type: [String],
      validate: [(v) => v.length >= 2, "At least two options are required"],
    },
    correctIndex: { type: Number, required: true },
    explanation: { type: String, default: "" },
    difficulty: { type: String, enum: ["Easy", "Medium", "Hard"], default: "Easy" },
  },
  { timestamps: true }
);

export default mongoose.model("Question", questionSchema);
