import mongoose from "mongoose";

const progressSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    problem: { type: mongoose.Schema.Types.ObjectId, ref: "Problem", required: true },
    track: { type: String, required: true },
    solved: { type: Boolean, default: false },
    markedForRevision: { type: Boolean, default: false },
    note: { type: String, default: "", maxlength: 4000 },
    solvedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

progressSchema.index({ user: 1, problem: 1 }, { unique: true });

export default mongoose.model("Progress", progressSchema);
