import mongoose from "mongoose";

const trackSchema = new mongoose.Schema(
  {
    key: { type: String, required: true, unique: true }, // dsa, development, aptitude, reasoning, corecs, system-design, interview
    title: { type: String, required: true },
    tagline: { type: String, default: "" },
    icon: { type: String, default: "code" },
    accent: { type: String, default: "violet" },
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export default mongoose.model("Track", trackSchema);
