import mongoose from "mongoose";
import bcrypt from "bcryptjs";

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, "Name is required"], trim: true, maxlength: 60 },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, "Enter a valid email address"],
    },
    password: { type: String, required: [true, "Password is required"], minlength: 6, select: false },
    role: { type: String, enum: ["student", "admin"], default: "student" },
    college: { type: String, default: "" },
    gradYear: { type: Number, default: null },
    targetRole: { type: String, default: "SDE" },
    dailyGoalMinutes: { type: Number, default: 45 },
    streak: { count: { type: Number, default: 0 }, lastActiveOn: { type: Date, default: null } },
    minutesLearned: { type: Number, default: 0 },
    bookmarks: [{ type: mongoose.Schema.Types.ObjectId, ref: "Problem" }],
  },
  { timestamps: true }
);

userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

userSchema.methods.matchPassword = function (entered) {
  return bcrypt.compare(entered, this.password);
};

userSchema.methods.touchStreak = function () {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const last = this.streak.lastActiveOn ? new Date(this.streak.lastActiveOn) : null;
  if (last) last.setHours(0, 0, 0, 0);

  if (!last) this.streak.count = 1;
  else {
    const diffDays = Math.round((today - last) / 86400000);
    if (diffDays === 0) return;
    this.streak.count = diffDays === 1 ? this.streak.count + 1 : 1;
  }
  this.streak.lastActiveOn = today;
};

export default mongoose.model("User", userSchema);
