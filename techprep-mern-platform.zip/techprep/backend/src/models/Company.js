import mongoose from "mongoose";

const companySchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true },
    slug: { type: String, required: true, unique: true },
    logoText: { type: String, default: "" },
    role: { type: String, default: "SDE-1" },
    ctc: { type: String, default: "" },
    difficulty: { type: String, enum: ["Easy", "Medium", "Hard"], default: "Medium" },
    rounds: [{ name: String, detail: String }],
    focusAreas: [String],
    topProblems: [String],
  },
  { timestamps: true }
);

export default mongoose.model("Company", companySchema);
