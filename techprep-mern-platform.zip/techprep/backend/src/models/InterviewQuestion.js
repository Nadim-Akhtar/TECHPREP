import mongoose from "mongoose";

const interviewQuestionSchema = new mongoose.Schema(
  {
    category: { type: String, required: true }, // HR | Technical | Behavioural | System Design
    question: { type: String, required: true },
    answer: { type: String, default: "" },
    tips: [String],
    companies: [String],
  },
  { timestamps: true }
);

export default mongoose.model("InterviewQuestion", interviewQuestionSchema);
