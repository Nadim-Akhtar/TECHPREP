import mongoose from "mongoose";

const problemSchema = new mongoose.Schema(
  {
    track: { type: String, required: true, index: true }, // dsa | development | corecs ...
    section: { type: String, required: true },   // "Learn the Basics"
    topic: { type: String, required: true },     // "Things to Know in Any Programming Language"
    title: { type: String, required: true },
    slug: { type: String, required: true, unique: true },
    difficulty: { type: String, enum: ["Easy", "Medium", "Hard"], default: "Easy" },
    tags: [String],
    articleUrl: { type: String, default: "" },
    videoUrl: { type: String, default: "" },
    practiceUrl: { type: String, default: "" },
    companies: [String],
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

problemSchema.index({ title: "text", tags: "text", topic: "text" });

export default mongoose.model("Problem", problemSchema);
