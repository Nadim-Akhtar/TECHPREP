import InterviewQuestion from "../models/InterviewQuestion.js";
import Company from "../models/Company.js";

export const getInterviewQuestions = async (req, res) => {
  const { category, search } = req.query;
  const filter = {};
  if (category && category !== "all") filter.category = category;
  if (search) filter.question = { $regex: search, $options: "i" };
  const questions = await InterviewQuestion.find(filter).sort({ category: 1 }).lean();
  res.json({ count: questions.length, questions });
};

export const getCompanies = async (req, res) => {
  const { search } = req.query;
  const filter = search ? { name: { $regex: search, $options: "i" } } : {};
  const companies = await Company.find(filter).sort({ name: 1 }).lean();
  res.json({ count: companies.length, companies });
};

export const getCompanyBySlug = async (req, res) => {
  const company = await Company.findOne({ slug: req.params.slug });
  if (!company) {
    res.status(404);
    throw new Error("Company not found.");
  }
  res.json(company);
};
