import User from "../models/User.js";
import { generateToken } from "../utils/generateToken.js";

const shape = (user) => ({
  _id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
  college: user.college,
  gradYear: user.gradYear,
  targetRole: user.targetRole,
  dailyGoalMinutes: user.dailyGoalMinutes,
  streak: user.streak,
  minutesLearned: user.minutesLearned,
});

// POST /api/auth/register
export const register = async (req, res) => {
  const { name, email, password, college, gradYear } = req.body;
  if (!name || !email || !password) {
    res.status(400);
    throw new Error("Name, email and password are required.");
  }
  const exists = await User.findOne({ email: email.toLowerCase() });
  if (exists) {
    res.status(400);
    throw new Error("An account with this email already exists.");
  }
  const user = await User.create({ name, email, password, college, gradYear });
  res.status(201).json({ user: shape(user), token: generateToken(user._id) });
};

// POST /api/auth/login
export const login = async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: (email || "").toLowerCase() }).select("+password");
  if (!user || !(await user.matchPassword(password))) {
    res.status(401);
    throw new Error("Email or password is incorrect.");
  }
  user.touchStreak();
  await user.save();
  res.json({ user: shape(user), token: generateToken(user._id) });
};

// GET /api/auth/me
export const getMe = async (req, res) => {
  res.json({ user: shape(req.user) });
};

// PUT /api/auth/me
export const updateMe = async (req, res) => {
  const fields = ["name", "college", "gradYear", "targetRole", "dailyGoalMinutes"];
  fields.forEach((f) => {
    if (req.body[f] !== undefined) req.user[f] = req.body[f];
  });
  if (req.body.password) req.user.password = req.body.password;
  const saved = await req.user.save();
  res.json({ user: shape(saved) });
};
