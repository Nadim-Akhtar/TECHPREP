import Progress from "../models/Progress.js";
import Problem from "../models/Problem.js";
import Attempt from "../models/Attempt.js";

const upsert = async (userId, problemId, update) => {
  const problem = await Problem.findById(problemId);
  if (!problem) {
    const err = new Error("Problem not found.");
    err.status = 404;
    throw err;
  }
  return Progress.findOneAndUpdate(
    { user: userId, problem: problemId },
    { $set: { track: problem.track, ...update } },
    { new: true, upsert: true, setDefaultsOnInsert: true }
  );
};

// PATCH /api/progress/:problemId/solve
export const toggleSolved = async (req, res) => {
  const existing = await Progress.findOne({ user: req.user._id, problem: req.params.problemId });
  const nextSolved = existing ? !existing.solved : true;
  const progress = await upsert(req.user._id, req.params.problemId, {
    solved: nextSolved,
    solvedAt: nextSolved ? new Date() : null,
  });
  if (nextSolved) {
    req.user.touchStreak();
    await req.user.save();
  }
  res.json(progress);
};

// PATCH /api/progress/:problemId/revision
export const toggleRevision = async (req, res) => {
  const existing = await Progress.findOne({ user: req.user._id, problem: req.params.problemId });
  const progress = await upsert(req.user._id, req.params.problemId, {
    markedForRevision: existing ? !existing.markedForRevision : true,
  });
  res.json(progress);
};

// PUT /api/progress/:problemId/note
export const saveNote = async (req, res) => {
  const progress = await upsert(req.user._id, req.params.problemId, { note: req.body.note || "" });
  res.json(progress);
};

// GET /api/progress/summary
export const getSummary = async (req, res) => {
  const tracks = [
    { key: "dsa", title: "Data Structures & Algorithms", blurb: "Master problem-solving and coding patterns." },
    { key: "development", title: "Full Stack Development", blurb: "Learn frontend, backend and databases." },
    { key: "aptitude", title: "Quantitative Aptitude", blurb: "Improve speed and accuracy for assessments." },
    { key: "corecs", title: "Core Computer Science", blurb: "Prepare OS, DBMS, CN and OOPs." },
    { key: "system-design", title: "System Design", blurb: "Learn LLD and HLD fundamentals." },
    { key: "interview", title: "Interview Preparation", blurb: "HR, behavioural and technical rounds." },
  ];

  const totals = await Problem.aggregate([{ $group: { _id: "$track", total: { $sum: 1 } } }]);
  const solved = await Progress.aggregate([
    { $match: { user: req.user._id, solved: true } },
    { $group: { _id: "$track", solved: { $sum: 1 } } },
  ]);

  const totalMap = Object.fromEntries(totals.map((t) => [t._id, t.total]));
  const solvedMap = Object.fromEntries(solved.map((t) => [t._id, t.solved]));

  const data = tracks.map((t) => {
    const total = totalMap[t.key] || 0;
    const done = solvedMap[t.key] || 0;
    return { ...t, total, solved: done, percent: total ? Math.round((done / total) * 100) : 0 };
  });

  const grandTotal = data.reduce((a, t) => a + t.total, 0);
  const grandSolved = data.reduce((a, t) => a + t.solved, 0);
  const attempts = await Attempt.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(5).lean();

  const recent = await Progress.find({ user: req.user._id, solved: true })
    .sort({ solvedAt: -1 })
    .limit(6)
    .populate("problem", "title track difficulty slug")
    .lean();

  res.json({
    tracks: data,
    stats: {
      streak: req.user.streak.count,
      minutesLearned: req.user.minutesLearned,
      topicsCompleted: grandSolved,
      overallPercent: grandTotal ? Math.round((grandSolved / grandTotal) * 100) : 0,
      dailyGoalMinutes: req.user.dailyGoalMinutes,
    },
    recent,
    attempts,
  });
};

// POST /api/progress/learning-time  { minutes: 25 }
export const logLearningTime = async (req, res) => {
  const minutes = Number(req.body.minutes) || 0;
  req.user.minutesLearned += minutes;
  req.user.touchStreak();
  await req.user.save();
  res.json({ minutesLearned: req.user.minutesLearned, streak: req.user.streak });
};
