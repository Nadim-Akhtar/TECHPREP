import Question from "../models/Question.js";
import Attempt from "../models/Attempt.js";

// GET /api/questions?track=aptitude&topic=&limit=10
export const getQuestions = async (req, res) => {
  const { track = "aptitude", topic, difficulty, limit = 10 } = req.query;
  const match = { track };
  if (topic && topic !== "all") match.topic = topic;
  if (difficulty && difficulty !== "all") match.difficulty = difficulty;

  const questions = await Question.aggregate([
    { $match: match },
    { $sample: { size: Number(limit) } },
    { $project: { correctIndex: 0, explanation: 0 } },
  ]);
  res.json({ count: questions.length, questions });
};

// GET /api/questions/topics?track=aptitude
export const getTopics = async (req, res) => {
  const track = req.query.track || "aptitude";
  const topics = await Question.aggregate([
    { $match: { track } },
    { $group: { _id: "$topic", count: { $sum: 1 } } },
    { $sort: { _id: 1 } },
  ]);
  res.json(topics.map((t) => ({ topic: t._id, count: t.count })));
};

// POST /api/questions/submit  { track, topic, timeTakenSec, answers: [{questionId, chosen}] }
export const submitQuiz = async (req, res) => {
  const { track, topic = "Mixed", timeTakenSec = 0, answers = [] } = req.body;
  if (!answers.length) {
    res.status(400);
    throw new Error("Answer at least one question before submitting.");
  }

  const ids = answers.map((a) => a.questionId);
  const questions = await Question.find({ _id: { $in: ids } }).lean();
  const qMap = Object.fromEntries(questions.map((q) => [q._id.toString(), q]));

  const evaluated = answers.map((a) => {
    const q = qMap[a.questionId];
    const isCorrect = q ? q.correctIndex === a.chosen : false;
    return {
      question: a.questionId,
      chosen: a.chosen,
      isCorrect,
      correctIndex: q?.correctIndex,
      explanation: q?.explanation || "",
    };
  });

  const correct = evaluated.filter((e) => e.isCorrect).length;

  const attempt = await Attempt.create({
    user: req.user._id,
    track,
    topic,
    total: answers.length,
    correct,
    timeTakenSec,
    answers: evaluated.map(({ question, chosen, isCorrect }) => ({ question, chosen, isCorrect })),
  });

  req.user.touchStreak();
  await req.user.save();

  res.status(201).json({
    attemptId: attempt._id,
    total: answers.length,
    correct,
    score: Math.round((correct / answers.length) * 100),
    review: evaluated,
  });
};

// GET /api/questions/attempts
export const getAttempts = async (req, res) => {
  const attempts = await Attempt.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(20).lean();
  res.json(attempts);
};
