import Problem from "../models/Problem.js";
import Progress from "../models/Progress.js";

// GET /api/problems?track=dsa&topic=&difficulty=&search=&revision=true
export const getProblems = async (req, res) => {
  const { track = "dsa", topic, difficulty, search } = req.query;
  const filter = { track };
  if (topic && topic !== "all") filter.topic = topic;
  if (difficulty && difficulty !== "all") filter.difficulty = difficulty;
  if (search) filter.title = { $regex: search, $options: "i" };

  const problems = await Problem.find(filter).sort({ order: 1, createdAt: 1 }).lean();

  let progressMap = {};
  if (req.user) {
    const progress = await Progress.find({ user: req.user._id, track }).lean();
    progressMap = progress.reduce((acc, p) => {
      acc[p.problem.toString()] = p;
      return acc;
    }, {});
  }

  const withProgress = problems.map((p) => {
    const pr = progressMap[p._id.toString()];
    return {
      ...p,
      solved: pr?.solved || false,
      markedForRevision: pr?.markedForRevision || false,
      note: pr?.note || "",
    };
  });

  const filtered = req.query.revision === "true" ? withProgress.filter((p) => p.markedForRevision) : withProgress;

  res.json({ count: filtered.length, problems: filtered });
};

// GET /api/problems/roadmap?track=dsa  -> grouped by section > topic
export const getRoadmap = async (req, res) => {
  const track = req.query.track || "dsa";
  const problems = await Problem.find({ track }).sort({ order: 1 }).lean();

  let progressMap = {};
  if (req.user) {
    const progress = await Progress.find({ user: req.user._id, track }).lean();
    progressMap = progress.reduce((a, p) => ({ ...a, [p.problem.toString()]: p }), {});
  }

  const sections = [];
  problems.forEach((p) => {
    const pr = progressMap[p._id.toString()];
    const item = {
      ...p,
      solved: pr?.solved || false,
      markedForRevision: pr?.markedForRevision || false,
      note: pr?.note || "",
    };
    let section = sections.find((s) => s.name === p.section);
    if (!section) {
      section = { name: p.section, topics: [], total: 0, solved: 0 };
      sections.push(section);
    }
    let topic = section.topics.find((t) => t.name === p.topic);
    if (!topic) {
      topic = { name: p.topic, problems: [], total: 0, solved: 0 };
      section.topics.push(topic);
    }
    topic.problems.push(item);
    topic.total += 1;
    section.total += 1;
    if (item.solved) {
      topic.solved += 1;
      section.solved += 1;
    }
  });

  const totals = { total: problems.length, solved: sections.reduce((a, s) => a + s.solved, 0) };
  const byDifficulty = ["Easy", "Medium", "Hard"].map((d) => {
    const all = problems.filter((p) => p.difficulty === d);
    const done = all.filter((p) => progressMap[p._id.toString()]?.solved).length;
    return { difficulty: d, total: all.length, solved: done };
  });

  res.json({ track, sections, totals, byDifficulty });
};

// GET /api/problems/:slug
export const getProblemBySlug = async (req, res) => {
  const problem = await Problem.findOne({ slug: req.params.slug });
  if (!problem) {
    res.status(404);
    throw new Error("Problem not found.");
  }
  res.json(problem);
};

// GET /api/problems/random?track=dsa
export const getRandomProblem = async (req, res) => {
  const track = req.query.track || "dsa";
  const [problem] = await Problem.aggregate([{ $match: { track } }, { $sample: { size: 1 } }]);
  if (!problem) {
    res.status(404);
    throw new Error("No problems in this track yet.");
  }
  res.json(problem);
};

// POST /api/problems (admin)
export const createProblem = async (req, res) => {
  const problem = await Problem.create(req.body);
  res.status(201).json(problem);
};
