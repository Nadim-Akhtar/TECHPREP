// Express 4 does not forward rejected promises, so every async route is wrapped.
export const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);
